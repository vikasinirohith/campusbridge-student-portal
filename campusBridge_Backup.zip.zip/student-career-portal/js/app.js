/**
 * CampusBridge - Main Application Controller
 * Handles UI interactions, rendering, filtering, modals, and event bindings.
 */

// Global App State
const AppState = {
  currentTab: "jobs", // jobs | tracker | eligibility | profile | insights
  searchQuery: "",
  typeFilter: "all",
  modeFilter: "all",
  departmentFilter: "all",
  onlyEligible: false,
  sortBy: "match", // match | stipend | newest | deadline
  selectedJobForModal: null,
  activeFilterBookmark: false
};

// DOM Cache & Initialization
document.addEventListener("DOMContentLoaded", () => {
  initApp();
});

function initApp() {
  // Setup theme
  const savedTheme = StorageService.getTheme();
  document.documentElement.setAttribute("data-theme", savedTheme);

  // Bind Header & Navigation
  setupNavigation();
  setupStudentSwitcher();
  setupThemeToggle();
  setupModals();
  setupJobFilters();

  // Render Initial View
  renderCurrentStudentHeader();
  renderAll();

  // Listen to state changes
  window.addEventListener("campusbridge:profileChanged", () => {
    renderCurrentStudentHeader();
    renderAll();
    showToast("Switched student profile successfully");
  });

  window.addEventListener("campusbridge:profileUpdated", () => {
    renderCurrentStudentHeader();
    renderAll();
    showToast("Profile updated successfully!");
  });

  window.addEventListener("campusbridge:backendSynced", () => {
    renderCurrentStudentHeader();
    setupStudentSwitcher();
    renderAll();
  });

  window.addEventListener("campusbridge:applicationsUpdated", () => {
    renderTracker();
    renderJobs();
    updateBadgeCounts();
  });

  window.addEventListener("campusbridge:bookmarksUpdated", () => {
    renderJobs();
    updateBadgeCounts();
  });

  window.addEventListener("campusbridge:jobsUpdated", () => {
    renderJobs();
    renderInsights();
    showToast("New opportunity posted to board!");
  });
}

function renderAll() {
  renderJobs();
  renderTracker();
  renderProfile();
  renderInsights();
  renderEligibilityRadar();
  updateBadgeCounts();
}

// -------------------------------------------------------------
// Navigation & Tabs
// -------------------------------------------------------------
function setupNavigation() {
  const navTabs = document.querySelectorAll(".nav-tab");
  navTabs.forEach(tab => {
    tab.addEventListener("click", (e) => {
      e.preventDefault();
      const target = tab.dataset.tab;
      switchTab(target);
    });
  });
}

function switchTab(tabId) {
  AppState.currentTab = tabId;
  document.querySelectorAll(".nav-tab").forEach(t => {
    t.classList.toggle("active", t.dataset.tab === tabId);
  });

  document.querySelectorAll(".view-section").forEach(sec => {
    sec.classList.toggle("hidden", sec.id !== `view-${tabId}`);
  });

  if (tabId === "tracker") renderTracker();
  if (tabId === "profile") renderProfile();
  if (tabId === "insights") renderInsights();
  if (tabId === "eligibility") renderEligibilityRadar();
  if (tabId === "jobs") renderJobs();

  window.scrollTo({ top: 0, behavior: "smooth" });
}

// -------------------------------------------------------------
// Theme & Student Switcher
// -------------------------------------------------------------
function setupThemeToggle() {
  const btn = document.getElementById("theme-toggle-btn");
  if (!btn) return;
  const currentTheme = StorageService.getTheme();
  btn.innerHTML = currentTheme === "dark" ? getSvgIcon("sun") : getSvgIcon("moon");
  btn.addEventListener("click", () => {
    const current = document.documentElement.getAttribute("data-theme") || "light";
    const next = current === "dark" ? "light" : "dark";
    StorageService.setTheme(next);
    btn.innerHTML = next === "dark" ? getSvgIcon("sun") : getSvgIcon("moon");
  });
}

function setupStudentSwitcher() {
  const switcherSelect = document.getElementById("student-switcher-select");
  if (!switcherSelect) return;

  const profiles = StorageService.getAllProfiles();
  const current = StorageService.getCurrentProfile();

  switcherSelect.innerHTML = profiles.map(p => {
    const deptTag = p.department || (p.degree ? p.degree.split(" ")[0] : "CS");
    return `
      <option value="${p.id}" ${p.id === current.id ? "selected" : ""}>
        ${p.name} (CGPA: ${p.cgpa} • ${deptTag})
      </option>
    `;
  }).join("");

  switcherSelect.onchange = (e) => {
    StorageService.setCurrentProfileId(e.target.value);
  };
}

function renderCurrentStudentHeader() {
  const student = StorageService.getCurrentProfile();
  const avatarName = document.getElementById("header-student-name");
  const avatarCgpa = document.getElementById("header-student-cgpa");
  const avatarDegree = document.getElementById("header-student-degree");
  const avatarBadge = document.getElementById("header-avatar-initials");

  if (avatarName) avatarName.textContent = student.name;
  if (avatarCgpa) avatarCgpa.textContent = `CGPA ${student.cgpa}/10`;
  if (avatarDegree) avatarDegree.textContent = `${student.degree} (${student.gradYear})`;
  if (avatarBadge) {
    const parts = student.name.split(" ");
    avatarBadge.textContent = (parts[0][0] + (parts[1] ? parts[1][0] : "")).toUpperCase();
  }

  // Update switcher select value if changed externally
  const switcherSelect = document.getElementById("student-switcher-select");
  if (switcherSelect && switcherSelect.value !== student.id) {
    switcherSelect.value = student.id;
  }
}

function updateBadgeCounts() {
  const student = StorageService.getCurrentProfile();
  const jobs = StorageService.getAllJobs();
  const apps = StorageService.getApplicationsForCurrentStudent();
  const bookmarks = StorageService.getBookmarks();

  // Eligible jobs count
  let eligibleCount = 0;
  jobs.forEach(job => {
    const evalResult = EligibilityEngine.evaluate(student, job);
    if (evalResult.verdict === "ELIGIBLE") eligibleCount++;
  });

  const eligibleBadge = document.getElementById("badge-eligible-count");
  if (eligibleBadge) eligibleBadge.textContent = `${eligibleCount} Eligible`;

  const appsBadge = document.getElementById("nav-badge-apps");
  if (appsBadge) appsBadge.textContent = apps.length;

  const savedBadge = document.getElementById("filter-saved-count");
  if (savedBadge) savedBadge.textContent = bookmarks.length;
}

// -------------------------------------------------------------
// Job Listings & Filters
// -------------------------------------------------------------
function setupJobFilters() {
  const searchInput = document.getElementById("job-search-input");
  const typeFilter = document.getElementById("filter-job-type");
  const modeFilter = document.getElementById("filter-work-mode");
  const deptFilter = document.getElementById("filter-department");
  const eligibleToggle = document.getElementById("toggle-only-eligible");
  const sortSelect = document.getElementById("select-sort-by");
  const savedOnlyBtn = document.getElementById("btn-filter-saved");

  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      AppState.searchQuery = e.target.value.toLowerCase().trim();
      renderJobs();
    });
  }

  if (typeFilter) {
    typeFilter.addEventListener("change", (e) => {
      AppState.typeFilter = e.target.value;
      renderJobs();
    });
  }

  if (modeFilter) {
    modeFilter.addEventListener("change", (e) => {
      AppState.modeFilter = e.target.value;
      renderJobs();
    });
  }

  if (deptFilter) {
    deptFilter.addEventListener("change", (e) => {
      AppState.departmentFilter = e.target.value;
      renderJobs();
    });
  }

  if (eligibleToggle) {
    eligibleToggle.addEventListener("change", (e) => {
      AppState.onlyEligible = e.target.checked;
      renderJobs();
    });
  }

  if (sortSelect) {
    sortSelect.addEventListener("change", (e) => {
      AppState.sortBy = e.target.value;
      renderJobs();
    });
  }

  if (savedOnlyBtn) {
    savedOnlyBtn.addEventListener("click", () => {
      AppState.activeFilterBookmark = !AppState.activeFilterBookmark;
      savedOnlyBtn.classList.toggle("btn-active", AppState.activeFilterBookmark);
      renderJobs();
    });
  }

  const clearBtn = document.getElementById("btn-clear-filters");
  if (clearBtn) {
    clearBtn.addEventListener("click", () => {
      AppState.searchQuery = "";
      AppState.typeFilter = "all";
      AppState.modeFilter = "all";
      AppState.departmentFilter = "all";
      AppState.onlyEligible = false;
      AppState.sortBy = "match";
      AppState.activeFilterBookmark = false;

      if (searchInput) searchInput.value = "";
      if (typeFilter) typeFilter.value = "all";
      if (modeFilter) modeFilter.value = "all";
      if (deptFilter) deptFilter.value = "all";
      if (eligibleToggle) eligibleToggle.checked = false;
      if (sortSelect) sortSelect.value = "match";
      if (savedOnlyBtn) savedOnlyBtn.classList.remove("btn-active");

      renderJobs();
      showToast("Filters reset to default");
    });
  }
}

function renderJobs() {
  const container = document.getElementById("jobs-grid-container");
  const resultsCount = document.getElementById("jobs-results-count");
  if (!container) return;

  const student = StorageService.getCurrentProfile();
  const allJobs = StorageService.getAllJobs();
  const bookmarks = StorageService.getBookmarks();

  // Filter jobs
  let filtered = allJobs.map(job => {
    const evalResult = EligibilityEngine.evaluate(student, job);
    return { ...job, evaluation: evalResult };
  });

  if (AppState.searchQuery) {
    const q = AppState.searchQuery;
    filtered = filtered.filter(job => {
      const titleMatch = job.title.toLowerCase().includes(q);
      const companyMatch = job.company.toLowerCase().includes(q);
      const locMatch = job.location.toLowerCase().includes(q);
      const skillMatch = job.requiredSkills.some(s => s.toLowerCase().includes(q));
      return titleMatch || companyMatch || locMatch || skillMatch;
    });
  }

  if (AppState.typeFilter !== "all") {
    filtered = filtered.filter(j => j.type.toLowerCase() === AppState.typeFilter.toLowerCase());
  }

  if (AppState.modeFilter !== "all") {
    filtered = filtered.filter(j => j.workMode.toLowerCase() === AppState.modeFilter.toLowerCase());
  }

  if (AppState.departmentFilter !== "all") {
    filtered = filtered.filter(j => j.department.toLowerCase().includes(AppState.departmentFilter.toLowerCase()));
  }

  if (AppState.onlyEligible) {
    filtered = filtered.filter(j => j.evaluation.verdict === "ELIGIBLE");
  }

  if (AppState.activeFilterBookmark) {
    filtered = filtered.filter(j => bookmarks.includes(j.id));
  }

  // Sorting
  filtered.sort((a, b) => {
    if (AppState.sortBy === "match") {
      return b.evaluation.score - a.evaluation.score;
    } else if (AppState.sortBy === "stipend") {
      return (b.stipendNumeric || 0) - (a.stipendNumeric || 0);
    } else if (AppState.sortBy === "newest") {
      return new Date(b.postedAt) - new Date(a.postedAt);
    } else if (AppState.sortBy === "deadline") {
      return new Date(a.deadline) - new Date(b.deadline);
    }
    return 0;
  });

  if (resultsCount) {
    resultsCount.textContent = `Showing ${filtered.length} opportunity${filtered.length === 1 ? "" : "ies"}`;
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">${getSvgIcon("search")}</div>
        <h3>No matching jobs or internships found</h3>
        <p>Try adjusting your search criteria, clearing filters, or switching the "Only Eligible" toggle.</p>
        <button class="btn btn-primary" onclick="document.getElementById('btn-clear-filters').click()">Clear All Filters</button>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(job => createJobCardHtml(job, student, bookmarks)).join("");

  // Attach event listeners to card buttons
  attachJobCardListeners(container);
}

function createJobCardHtml(job, student, bookmarks) {
  const isBookmarked = bookmarks.includes(job.id);
  const hasApplied = StorageService.hasStudentApplied(job.id);
  const evalResult = job.evaluation;

  let badgeClass = "badge-ineligible";
  let badgeText = "Ineligible";
  let badgeIcon = getSvgIcon("alert-circle");

  if (evalResult.verdict === "ELIGIBLE") {
    badgeClass = "badge-eligible";
    badgeText = `Eligible • ${evalResult.score}% Match`;
    badgeIcon = getSvgIcon("check-circle");
  } else if (evalResult.verdict === "PARTIAL") {
    badgeClass = "badge-partial";
    badgeText = `Partial • ${evalResult.score}% Match`;
    badgeIcon = getSvgIcon("alert-triangle");
  } else {
    badgeText = `Ineligible • Min CGPA ${job.minCgpa}`;
  }

  // Format skills with highlight if student possesses them
  const skillsHtml = job.requiredSkills.map(reqSkill => {
    const matched = EligibilityEngine.hasSkill(student.skills, reqSkill);
    return `<span class="skill-pill ${matched ? "skill-matched" : "skill-missing"}">
      ${matched ? "✓" : "○"} ${reqSkill}
    </span>`;
  }).join("");

  return `
    <div class="job-card ${job.featured ? "card-featured" : ""}" data-job-id="${job.id}">
      <div class="job-card-header">
        <div class="company-brand">
          <div class="company-logo" style="background-color: ${job.logoBg || "#4F46E5"}">
            ${job.companyInitial || job.company[0]}
          </div>
          <div>
            <h4 class="company-name">${escapeHtml(job.company)}</h4>
            <span class="job-location">${getSvgIcon("map-pin")} ${escapeHtml(job.location)}</span>
          </div>
        </div>
        <button class="btn-icon-bookmark ${isBookmarked ? "bookmarked" : ""}" data-action="bookmark" title="${isBookmarked ? "Saved" : "Save Job"}">
          ${getSvgIcon(isBookmarked ? "bookmark-filled" : "bookmark")}
        </button>
      </div>

      <h3 class="job-title">${escapeHtml(job.title)}</h3>

      <div class="job-meta-row">
        <span class="meta-tag meta-type">${escapeHtml(job.type)}</span>
        <span class="meta-tag meta-mode">${escapeHtml(job.workMode)}</span>
        <span class="meta-tag meta-stipend">${escapeHtml(job.stipend)}</span>
        <span class="meta-tag meta-cgpa">Min CGPA: <strong>${job.minCgpa}</strong></span>
      </div>

      <!-- Eligibility Badge Bar -->
      <div class="eligibility-status-bar ${badgeClass}">
        <span class="status-icon">${badgeIcon}</span>
        <span class="status-label">${badgeText}</span>
        <button class="btn-text-check" data-action="check-eligibility">Breakdown »</button>
      </div>

      <!-- Skills required -->
      <div class="job-skills-list">
        ${skillsHtml}
      </div>

      <!-- Card Footer -->
      <div class="job-card-footer">
        <span class="job-deadline">${getSvgIcon("clock")} Apply by ${formatDate(job.deadline)}</span>
        <div class="card-action-group">
          <button class="btn btn-secondary btn-sm" data-action="view-details">Details</button>
          ${hasApplied ? `
            <button class="btn btn-applied btn-sm" disabled>
              ${getSvgIcon("check")} Applied
            </button>
          ` : `
            <button class="btn btn-primary btn-sm" data-action="apply-job">
              Apply Now
            </button>
          `}
        </div>
      </div>
    </div>
  `;
}

function attachJobCardListeners(container) {
  container.querySelectorAll("[data-action='bookmark']").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const card = btn.closest(".job-card");
      const jobId = card.dataset.jobId;
      const saved = StorageService.toggleBookmark(jobId);
      showToast(saved ? "Job saved to bookmarks" : "Job removed from bookmarks");
    });
  });

  container.querySelectorAll("[data-action='check-eligibility']").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const card = btn.closest(".job-card");
      const jobId = card.dataset.jobId;
      openEligibilityModal(jobId);
    });
  });

  container.querySelectorAll("[data-action='view-details']").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const card = btn.closest(".job-card");
      const jobId = card.dataset.jobId;
      openJobDetailsModal(jobId);
    });
  });

  container.querySelectorAll("[data-action='apply-job']").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const card = btn.closest(".job-card");
      const jobId = card.dataset.jobId;
      openApplyModal(jobId);
    });
  });
}

// -------------------------------------------------------------
// Modals Handling (Eligibility, Details, Apply, Post Job, Resume)
// -------------------------------------------------------------
function setupModals() {
  document.querySelectorAll(".modal-close-btn, .modal-backdrop").forEach(el => {
    el.addEventListener("click", (e) => {
      if (e.target.classList.contains("modal-backdrop") || e.target.classList.contains("modal-close-btn")) {
        closeAllModals();
      }
    });
  });

  // Auth Modal trigger
  const authModalBtn = document.getElementById("btn-open-auth-modal");
  if (authModalBtn) {
    authModalBtn.addEventListener("click", () => {
      openModal("modal-auth");
    });
  }

  // Auth Tabs switcher
  const tabLoginBtn = document.getElementById("auth-tab-btn-login");
  const tabRegBtn = document.getElementById("auth-tab-btn-register");
  const formLogin = document.getElementById("form-auth-login");
  const formReg = document.getElementById("form-auth-register");

  if (tabLoginBtn && tabRegBtn) {
    tabLoginBtn.addEventListener("click", () => {
      tabLoginBtn.classList.add("active");
      tabRegBtn.classList.remove("active");
      if (formLogin) formLogin.classList.remove("hidden");
      if (formReg) formReg.classList.add("hidden");
    });

    tabRegBtn.addEventListener("click", () => {
      tabRegBtn.classList.add("active");
      tabLoginBtn.classList.remove("active");
      if (formReg) formReg.classList.remove("hidden");
      if (formLogin) formLogin.classList.add("hidden");
    });
  }

  if (formLogin) {
    formLogin.addEventListener("submit", async (e) => {
      e.preventDefault();
      const email = document.getElementById("login-email").value.trim();
      const password = document.getElementById("login-password").value;
      try {
        const student = await StorageService.login(email, password);
        closeAllModals();
        showToast(`Welcome back, ${student.name}!`);
      } catch (err) {
        alert(err.message || "Login failed. Check your email & password.");
      }
    });
  }

function fillDemoLogin(email, password) {
  const emailInput = document.getElementById("login-email");
  const passInput = document.getElementById("login-password");
  if (emailInput) emailInput.value = email;
  if (passInput) passInput.value = password;
  showToast(`Loaded demo credentials for ${email}`);
}

  if (formReg) {
    formReg.addEventListener("submit", async (e) => {
      e.preventDefault();
      const skillsVal = document.getElementById("reg-skills").value;
      const skillsList = skillsVal.split(",").map(s => s.trim()).filter(Boolean);
      const studentData = {
        name: document.getElementById("reg-name").value.trim(),
        email: document.getElementById("reg-email").value.trim(),
        password: document.getElementById("reg-password").value,
        phone: document.getElementById("reg-phone").value.trim(),
        university: document.getElementById("reg-university").value.trim(),
        department: document.getElementById("reg-department").value,
        degree: document.getElementById("reg-degree").value.trim(),
        gradYear: parseInt(document.getElementById("reg-grad-year").value, 10),
        cgpa: parseFloat(document.getElementById("reg-cgpa").value),
        skills: skillsList
      };

      try {
        const student = await StorageService.register(studentData);
        closeAllModals();
        formReg.reset();
        showToast(`Welcome to CampusBridge, ${student.name}! Account registered.`);
      } catch (err) {
        alert(err.message || "Registration failed.");
      }
    });
  }

  // Post Job Modal trigger
  const postJobBtn = document.getElementById("btn-open-post-job-modal");
  if (postJobBtn) {
    postJobBtn.addEventListener("click", () => {
      openModal("modal-post-job");
    });
  }

  // Handle Post Job Form Submit
  const postJobForm = document.getElementById("form-post-job");
  if (postJobForm) {
    postJobForm.addEventListener("submit", handlePostJobSubmit);
  }

  // Handle Apply Form Submit
  const applyForm = document.getElementById("form-apply-job");
  if (applyForm) {
    applyForm.addEventListener("submit", handleApplySubmit);
  }

  // Keyboard Escape to close
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeAllModals();
  });
}

function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add("active");
    document.body.style.overflow = "hidden";
  }
}

function closeAllModals() {
  document.querySelectorAll(".modal").forEach(m => m.classList.remove("active"));
  document.body.style.overflow = "";
}

function openEligibilityModal(jobId) {
  const job = StorageService.getJobById(jobId);
  const student = StorageService.getCurrentProfile();
  if (!job || !student) return;

  const evalResult = EligibilityEngine.evaluate(student, job);
  const modalContent = document.getElementById("eligibility-modal-content");
  if (!modalContent) return;

  let verdictColor = "#EF4444";
  let verdictTitle = "Ineligible for this role";
  if (evalResult.verdict === "ELIGIBLE") {
    verdictColor = "#10B981";
    verdictTitle = "Highly Eligible Candidate!";
  } else if (evalResult.verdict === "PARTIAL") {
    verdictColor = "#F59E0B";
    verdictTitle = "Partially Eligible • Skill Gap Detected";
  }

  modalContent.innerHTML = `
    <div class="eligibility-report-card">
      <div class="report-header" style="border-left: 5px solid ${verdictColor}">
        <div>
          <h3>${escapeHtml(job.title)}</h3>
          <p class="company-sub">${escapeHtml(job.company)} • ${escapeHtml(job.location)}</p>
        </div>
        <div class="score-circle" style="border-color: ${verdictColor}">
          <span class="score-num">${evalResult.score}</span>
          <span class="score-label">MATCH SCORE</span>
        </div>
      </div>

      <div class="verdict-banner" style="background-color: ${verdictColor}15; color: ${verdictColor}">
        <strong>${verdictTitle}</strong>
      </div>

      <!-- Comparison Metrics -->
      <div class="comparison-grid">
        <div class="metric-card ${evalResult.cgpaPassed ? "metric-pass" : "metric-fail"}">
          <div class="metric-title">
            <span>CGPA Requirement</span>
            <span class="metric-status-badge">${evalResult.cgpaPassed ? "PASSED" : "NOT MET"}</span>
          </div>
          <div class="metric-values">
            <div class="val-box">
              <span class="val-label">Your CGPA</span>
              <span class="val-number">${student.cgpa} / 10.0</span>
            </div>
            <div class="val-divider">vs</div>
            <div class="val-box">
              <span class="val-label">Min Cutoff</span>
              <span class="val-number">${job.minCgpa} / 10.0</span>
            </div>
          </div>
          <p class="metric-tip">
            ${evalResult.cgpaPassed 
              ? `You exceed the cutoff by +${evalResult.cgpaGap} points.` 
              : `You are short by ${Math.abs(evalResult.cgpaGap)} points.`}
          </p>
        </div>

        <div class="metric-card ${evalResult.batchPassed ? "metric-pass" : "metric-fail"}">
          <div class="metric-title">
            <span>Eligible Graduation Batches</span>
            <span class="metric-status-badge">${evalResult.batchPassed ? "PASSED" : "BATCH MISMATCH"}</span>
          </div>
          <div class="metric-values">
            <div class="val-box">
              <span class="val-label">Your Batch</span>
              <span class="val-number">${student.gradYear}</span>
            </div>
            <div class="val-divider">in</div>
            <div class="val-box">
              <span class="val-label">Target Batches</span>
              <span class="val-number">${job.eligibleBatches.join(", ") || "All Batches"}</span>
            </div>
          </div>
          <p class="metric-tip">
            ${evalResult.batchPassed ? "Graduation year verified." : "Only targeted batches accepted."}
          </p>
        </div>
      </div>

      <!-- Skills Breakdown Section -->
      <div class="skills-breakdown-section">
        <div class="section-heading-sm">
          <h4>Skills Match Analysis (${evalResult.skillMatchPct}%)</h4>
          <span>${evalResult.matchedSkills.length} of ${job.requiredSkills.length} mandatory skills matched</span>
        </div>

        <div class="skills-split-box">
          <div class="split-column">
            <h5 class="text-success">Matched Skills (${evalResult.matchedSkills.length})</h5>
            <div class="tags-cluster">
              ${evalResult.matchedSkills.length > 0 
                ? evalResult.matchedSkills.map(s => `<span class="badge-skill-matched">${getSvgIcon("check")} ${s}</span>`).join("")
                : `<span class="text-muted">No mandatory skills matched yet.</span>`}
            </div>
          </div>

          <div class="split-column">
            <h5 class="text-danger">Missing Skills (${evalResult.missingSkills.length})</h5>
            <div class="tags-cluster">
              ${evalResult.missingSkills.length > 0 
                ? evalResult.missingSkills.map(s => `<span class="badge-skill-missing">+ ${s}</span>`).join("")
                : `<span class="badge-skill-matched">You have all required skills! 🎉</span>`}
            </div>
          </div>
        </div>
      </div>

      <!-- Actionable Advice -->
      <div class="action-recommendations">
        <h4>Insights & Recommended Next Steps:</h4>
        <ul>
          ${evalResult.reasons.map(r => `<li>${escapeHtml(r)}</li>`).join("")}
          ${evalResult.recommendations.map(rec => `<li class="rec-highlight">${getSvgIcon("zap")} <strong>Tip:</strong> ${escapeHtml(rec)}</li>`).join("")}
        </ul>
      </div>

      <!-- Modal Footer CTA -->
      <div class="modal-cta-row">
        <button class="btn btn-secondary" onclick="closeAllModals()">Close</button>
        ${StorageService.hasStudentApplied(job.id) ? `
          <button class="btn btn-applied" disabled>${getSvgIcon("check")} Already Applied</button>
        ` : `
          <button class="btn btn-primary" onclick="closeAllModals(); openApplyModal('${job.id}')">
            Apply Now with Active Profile
          </button>
        `}
      </div>
    </div>
  `;

  openModal("modal-eligibility-details");
}

function openJobDetailsModal(jobId) {
  const job = StorageService.getJobById(jobId);
  const student = StorageService.getCurrentProfile();
  if (!job) return;

  const evalResult = EligibilityEngine.evaluate(student, job);
  const hasApplied = StorageService.hasStudentApplied(job.id);
  const modalContent = document.getElementById("job-details-modal-content");
  if (!modalContent) return;

  modalContent.innerHTML = `
    <div class="job-full-details">
      <div class="job-details-header">
        <div class="company-logo lg" style="background-color: ${job.logoBg || "#4F46E5"}">
          ${job.companyInitial || job.company[0]}
        </div>
        <div>
          <h2>${escapeHtml(job.title)}</h2>
          <div class="sub-line">
            <strong>${escapeHtml(job.company)}</strong> • ${escapeHtml(job.location)} • Posted on ${formatDate(job.postedAt)}
          </div>
        </div>
      </div>

      <div class="details-pill-row">
        <span class="meta-tag meta-type">${escapeHtml(job.type)}</span>
        <span class="meta-tag meta-mode">${escapeHtml(job.workMode)}</span>
        <span class="meta-tag meta-stipend">${escapeHtml(job.stipend)}</span>
        <span class="meta-tag meta-cgpa">Min CGPA: ${job.minCgpa}</span>
        <span class="meta-tag">${job.openings} Openings</span>
      </div>

      <div class="job-description-block">
        <h3>Role Overview</h3>
        <p>${escapeHtml(job.description)}</p>
      </div>

      <div class="job-requirements-block">
        <h3>Required Skills & Technologies</h3>
        <div class="tags-cluster">
          ${job.requiredSkills.map(s => {
            const has = EligibilityEngine.hasSkill(student.skills, s);
            return `<span class="skill-pill ${has ? "skill-matched" : "skill-missing"}">
              ${has ? "✓" : "○"} ${s}
            </span>`;
          }).join("")}
        </div>

        ${job.preferredSkills && job.preferredSkills.length > 0 ? `
          <h4 style="margin-top: 1rem;">Bonus / Preferred Skills</h4>
          <div class="tags-cluster">
            ${job.preferredSkills.map(s => `<span class="skill-pill">${s}</span>`).join("")}
          </div>
        ` : ""}
      </div>

      <div class="job-eligibility-summary">
        <div class="summary-box">
          <div>
            <strong>Your Match Status:</strong>
            <span>${evalResult.verdict} (${evalResult.score}% Match Score)</span>
          </div>
          <button class="btn btn-secondary btn-sm" onclick="closeAllModals(); openEligibilityModal('${job.id}')">
            Detailed Breakdown
          </button>
        </div>
      </div>

      <div class="modal-cta-row">
        <button class="btn btn-secondary" onclick="closeAllModals()">Close</button>
        ${hasApplied ? `
          <button class="btn btn-applied" disabled>${getSvgIcon("check")} Already Applied</button>
        ` : `
          <button class="btn btn-primary" onclick="closeAllModals(); openApplyModal('${job.id}')">
            Proceed to Apply
          </button>
        `}
      </div>
    </div>
  `;

  openModal("modal-job-details");
}

function openApplyModal(jobId) {
  const job = StorageService.getJobById(jobId);
  const student = StorageService.getCurrentProfile();
  if (!job || !student) return;

  AppState.selectedJobForModal = job;
  const evalResult = EligibilityEngine.evaluate(student, job);

  // Set inputs
  const jobTitleEl = document.getElementById("apply-modal-job-title");
  const compEl = document.getElementById("apply-modal-company");
  const studentNameEl = document.getElementById("apply-student-name");
  const studentEmailEl = document.getElementById("apply-student-email");
  const studentCgpaEl = document.getElementById("apply-student-cgpa");
  const resumeSelect = document.getElementById("apply-resume-select");
  const eligibilityBanner = document.getElementById("apply-eligibility-warning");

  if (jobTitleEl) jobTitleEl.textContent = job.title;
  if (compEl) compEl.textContent = `${job.company} • ${job.location}`;
  if (studentNameEl) studentNameEl.value = student.name;
  if (studentEmailEl) studentEmailEl.value = student.email;
  if (studentCgpaEl) studentCgpaEl.value = `${student.cgpa} / 10.0 (Min: ${job.minCgpa})`;

  if (resumeSelect) {
    resumeSelect.innerHTML = `
      <option value="${student.resumeFileName}">${student.resumeFileName} (Active Resume - ${student.resumeFileSize})</option>
      <option value="Custom_Uploaded_Resume.pdf">Upload New Version on Profile Tab...</option>
    `;
  }

  if (eligibilityBanner) {
    if (evalResult.verdict === "ELIGIBLE") {
      eligibilityBanner.className = "eligibility-alert alert-success";
      eligibilityBanner.innerHTML = `${getSvgIcon("check-circle")} <strong>All Clear!</strong> You meet the CGPA cutoff (${student.cgpa} >= ${job.minCgpa}) and match ${evalResult.skillMatchPct}% of skills.`;
    } else if (evalResult.verdict === "PARTIAL") {
      eligibilityBanner.className = "eligibility-alert alert-warning";
      eligibilityBanner.innerHTML = `${getSvgIcon("alert-triangle")} <strong>Partial Match (${evalResult.score}%):</strong> You qualify on CGPA but are missing: ${evalResult.missingSkills.join(", ")}. You can still submit!`;
    } else {
      eligibilityBanner.className = "eligibility-alert alert-danger";
      eligibilityBanner.innerHTML = `${getSvgIcon("alert-circle")} <strong>Warning:</strong> You do not currently meet the eligibility criteria (${evalResult.reasons[0]}). Submissions may be automatically flagged.`;
    }
  }

  openModal("modal-apply-job");
}

function handleApplySubmit(e) {
  e.preventDefault();
  const job = AppState.selectedJobForModal;
  const student = StorageService.getCurrentProfile();
  if (!job) return;

  const noteInput = document.getElementById("apply-cover-note");
  const resumeSelect = document.getElementById("apply-resume-select");
  const evalResult = EligibilityEngine.evaluate(student, job);

  try {
    StorageService.submitApplication({
      jobId: job.id,
      coverNote: noteInput ? noteInput.value.trim() : "",
      resumeUsed: resumeSelect ? resumeSelect.value : student.resumeFileName,
      matchScore: evalResult.score
    });

    closeAllModals();
    showToast(`Application submitted to ${job.company}!`);
    switchTab("tracker");
  } catch (err) {
    alert(err.message);
  }
}

function handlePostJobSubmit(e) {
  e.preventDefault();
  const form = e.target;

  const title = form["job-title"].value.trim();
  const company = form["job-company"].value.trim();
  const type = form["job-type"].value;
  const workMode = form["job-workmode"].value;
  const location = form["job-location"].value.trim() || "Remote";
  const department = form["job-department"].value;
  const stipend = form["job-stipend"].value.trim();
  const minCgpa = parseFloat(form["job-min-cgpa"].value) || 7.0;
  const batchesStr = form["job-batches"].value.trim();
  const skillsStr = form["job-skills"].value.trim();
  const deadline = form["job-deadline"].value || "2026-12-31";
  const description = form["job-description"].value.trim();

  const eligibleBatches = batchesStr 
    ? batchesStr.split(",").map(b => parseInt(b.trim(), 10)).filter(Boolean)
    : [2025, 2026, 2027];

  const requiredSkills = skillsStr
    ? skillsStr.split(",").map(s => s.trim()).filter(Boolean)
    : ["Python", "Problem Solving"];

  // Numeric stipend estimation
  const stipendNumeric = parseInt(stipend.replace(/[^0-9]/g, ""), 10) || 4000;

  StorageService.addJob({
    title,
    company,
    type,
    workMode,
    location,
    department,
    stipend,
    stipendNumeric,
    minCgpa,
    eligibleBatches,
    requiredSkills,
    preferredSkills: ["Git", "Communication"],
    deadline,
    description: description || "Exciting opportunity for college students and graduates.",
    openings: 3,
    logoBg: "#059669",
    companyInitial: company[0].toUpperCase(),
    featured: false
  });

  form.reset();
  closeAllModals();
  showToast("Opportunity posted successfully!");
  switchTab("jobs");
}

// -------------------------------------------------------------
// Application Tracker View (Kanban Board & Details)
// -------------------------------------------------------------
function renderTracker() {
  const container = document.getElementById("tracker-kanban-board");
  if (!container) return;

  const applications = StorageService.getApplicationsForCurrentStudent();
  const jobs = StorageService.getAllJobs();

  const stages = [
    { key: "applied", label: "Applied", badgeColor: "#3B82F6" },
    { key: "reviewing", label: "Under Review", badgeColor: "#8B5CF6" },
    { key: "interview", label: "Interview Scheduled", badgeColor: "#F59E0B" },
    { key: "offer", label: "Offer Received 🎉", badgeColor: "#10B981" },
    { key: "rejected", label: "Not Selected", badgeColor: "#6B7280" }
  ];

  container.innerHTML = stages.map(stage => {
    const stageApps = applications.filter(a => a.status === stage.key);
    return `
      <div class="kanban-column" data-stage="${stage.key}">
        <div class="kanban-column-header">
          <div class="stage-indicator" style="background-color: ${stage.badgeColor}"></div>
          <h4>${stage.label}</h4>
          <span class="column-count-badge">${stageApps.length}</span>
        </div>

        <div class="kanban-cards-list" ondragover="event.preventDefault()" ondrop="handleDropApp(event, '${stage.key}')">
          ${stageApps.length === 0 ? `
            <div class="kanban-empty-placeholder">No applications in this stage</div>
          ` : stageApps.map(app => {
            const job = jobs.find(j => j.id === app.jobId) || { location: "Unknown" };
            return `
              <div class="kanban-app-card" draggable="true" ondragstart="handleDragStartApp(event, '${app.id}')">
                <div class="app-card-top">
                  <span class="app-company">${escapeHtml(app.company)}</span>
                  <span class="app-match-badge">${app.matchScore}% Match</span>
                </div>
                <h4 class="app-job-title">${escapeHtml(app.jobTitle)}</h4>
                <div class="app-card-meta">
                  <span>${getSvgIcon("calendar")} Applied: ${formatDate(app.appliedDate)}</span>
                  <span>${getSvgIcon("file-text")} ${escapeHtml(app.resumeUsed)}</span>
                </div>

                ${app.notes ? `
                  <div class="app-card-notes">
                    <strong>Note:</strong> ${escapeHtml(app.notes)}
                  </div>
                ` : ""}

                <div class="app-card-actions">
                  <select class="select-stage-changer" onchange="StorageService.updateApplicationStatus('${app.id}', this.value)">
                    ${stages.map(s => `
                      <option value="${s.key}" ${s.key === stage.key ? "selected" : ""}>Move to: ${s.label}</option>
                    `).join("")}
                  </select>
                  <button class="btn-text-danger" onclick="confirmWithdrawApp('${app.id}')" title="Withdraw Application">
                    ${getSvgIcon("trash")}
                  </button>
                </div>
              </div>
            `;
          }).join("")}
        </div>
      </div>
    `;
  }).join("");
}

// Drag & Drop handlers for Kanban
let draggedAppId = null;
function handleDragStartApp(e, appId) {
  draggedAppId = appId;
  e.dataTransfer.setData("text/plain", appId);
}

function handleDropApp(e, newStage) {
  e.preventDefault();
  if (draggedAppId) {
    StorageService.updateApplicationStatus(draggedAppId, newStage);
    draggedAppId = null;
    showToast(`Application moved to ${newStage}`);
  }
}

function confirmWithdrawApp(appId) {
  if (confirm("Are you sure you want to withdraw this application? This cannot be undone.")) {
    StorageService.withdrawApplication(appId);
    showToast("Application withdrawn");
  }
}

// -------------------------------------------------------------
// Student Profile & Resume Manager
// -------------------------------------------------------------
function renderProfile() {
  const student = StorageService.getCurrentProfile();
  
  const nameInput = document.getElementById("profile-name");
  const emailInput = document.getElementById("profile-email");
  const phoneInput = document.getElementById("profile-phone");
  const uniInput = document.getElementById("profile-university");
  const degreeInput = document.getElementById("profile-degree");
  const gradYearInput = document.getElementById("profile-grad-year");
  const cgpaInput = document.getElementById("profile-cgpa");
  const cgpaDisplay = document.getElementById("profile-cgpa-display");
  const bioInput = document.getElementById("profile-bio");

  if (nameInput) nameInput.value = student.name || "";
  if (emailInput) emailInput.value = student.email || "";
  if (phoneInput) phoneInput.value = student.phone || "";
  if (uniInput) uniInput.value = student.university || "";
  if (degreeInput) degreeInput.value = student.degree || "";
  if (gradYearInput) gradYearInput.value = student.gradYear || 2026;
  if (cgpaInput) {
    cgpaInput.value = student.cgpa || 8.0;
    if (cgpaDisplay) cgpaDisplay.textContent = student.cgpa;
    cgpaInput.oninput = (e) => {
      if (cgpaDisplay) cgpaDisplay.textContent = parseFloat(e.target.value).toFixed(1);
    };
  }
  if (bioInput) bioInput.value = student.bio || "";

  renderProfileSkillsList(student.skills || []);
  renderResumePreviewBox(student);
  setupProfileFormListeners();
}

function renderProfileSkillsList(skills) {
  const container = document.getElementById("profile-skills-tags");
  if (!container) return;

  container.innerHTML = skills.map((skill, index) => `
    <span class="user-skill-chip">
      ${escapeHtml(skill)}
      <button type="button" class="btn-remove-skill" onclick="removeSkillFromProfile(${index})">&times;</button>
    </span>
  `).join("");

  // Also render recommended add chips
  const suggestedContainer = document.getElementById("suggested-skills-cloud");
  if (suggestedContainer) {
    const unadded = SKILL_DATABASE.filter(s => !skills.includes(s)).slice(0, 8);
    suggestedContainer.innerHTML = unadded.map(s => `
      <button type="button" class="btn-tag-suggest" onclick="addSkillToProfile('${s}')">+ ${s}</button>
    `).join("");
  }
}

function addSkillToProfile(skillName) {
  if (!skillName) return;
  const student = StorageService.getCurrentProfile();
  const skills = student.skills || [];
  if (!skills.includes(skillName)) {
    skills.push(skillName);
    StorageService.updateCurrentProfile({ skills });
  }
}

function removeSkillFromProfile(index) {
  const student = StorageService.getCurrentProfile();
  const skills = student.skills || [];
  skills.splice(index, 1);
  StorageService.updateCurrentProfile({ skills });
}

function setupProfileFormListeners() {
  const form = document.getElementById("form-student-profile");
  if (form && !form.dataset.bound) {
    form.dataset.bound = "true";
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const student = StorageService.getCurrentProfile();
      const updated = {
        name: document.getElementById("profile-name").value.trim(),
        email: document.getElementById("profile-email").value.trim(),
        phone: document.getElementById("profile-phone").value.trim(),
        university: document.getElementById("profile-university").value.trim(),
        degree: document.getElementById("profile-degree").value.trim(),
        gradYear: parseInt(document.getElementById("profile-grad-year").value, 10),
        cgpa: parseFloat(document.getElementById("profile-cgpa").value),
        bio: document.getElementById("profile-bio").value.trim()
      };
      StorageService.updateCurrentProfile(updated);
    });
  }

  // Skill Add Input listener
  const skillInput = document.getElementById("input-add-skill");
  const addBtn = document.getElementById("btn-add-skill-manual");
  if (addBtn && skillInput && !addBtn.dataset.bound) {
    addBtn.dataset.bound = "true";
    addBtn.addEventListener("click", () => {
      const val = skillInput.value.trim();
      if (val) {
        addSkillToProfile(val);
        skillInput.value = "";
      }
    });

    skillInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        addBtn.click();
      }
    });
  }

  // Resume file drop zone setup
  setupResumeDropzone();
}

function renderResumePreviewBox(student) {
  const box = document.getElementById("resume-active-info");
  if (!box) return;

  const strength = calculateResumeStrength(student);
  const downloadUrl = student.resumeFileName 
    ? (student.resumeFileName.startsWith("http") ? student.resumeFileName : `/uploads/${encodeURIComponent(student.resumeFileName)}`)
    : "";

  box.innerHTML = `
    <div class="resume-meta-card">
      <div class="resume-file-icon">${getSvgIcon("file-text")}</div>
      <div class="resume-details">
        <h4>${escapeHtml(student.resumeFileName || "Student_Resume.pdf")}</h4>
        <span class="text-muted">Uploaded on ${student.resumeUploadedAt || "2026-11-01"} • Size: ${student.resumeFileSize || "280 KB"}</span>
        <div class="resume-strength-meter">
          <div class="strength-bar-track">
            <div class="strength-bar-fill" style="width: ${strength.score}%"></div>
          </div>
          <span class="strength-score">Resume Score: <strong>${strength.score}/100</strong> (${strength.rating})</span>
        </div>
        ${student.resumeFileName ? `
          <div style="margin-top: 0.5rem;">
            <a href="${downloadUrl}" target="_blank" class="resume-download-link">
              ${getSvgIcon("file-text")} View / Download File
            </a>
          </div>
        ` : ""}
      </div>
    </div>
  `;
}

function calculateResumeStrength(student) {
  let score = 50;
  if (student.cgpa >= 8.0) score += 15;
  if (student.skills && student.skills.length >= 6) score += 20;
  if (student.bio && student.bio.length > 30) score += 10;
  if (student.githubUrl) score += 5;

  let rating = "Good";
  if (score >= 90) rating = "Excellent / ATS Optimized";
  else if (score >= 75) rating = "Strong Match";
  else rating = "Needs Optimization";

  return { score: Math.min(100, score), rating };
}

function setupResumeDropzone() {
  const dropzone = document.getElementById("resume-dropzone");
  const fileInput = document.getElementById("resume-file-input");
  if (!dropzone || !fileInput || dropzone.dataset.bound) return;

  dropzone.dataset.bound = "true";

  dropzone.addEventListener("click", () => fileInput.click());

  dropzone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropzone.classList.add("dragover");
  });

  dropzone.addEventListener("dragleave", () => {
    dropzone.classList.remove("dragover");
  });

  dropzone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropzone.classList.remove("dragover");
    if (e.dataTransfer.files.length > 0) {
      handleSimulatedResumeUpload(e.dataTransfer.files[0]);
    }
  });

  fileInput.addEventListener("change", (e) => {
    if (e.target.files.length > 0) {
      handleSimulatedResumeUpload(e.target.files[0]);
    }
  });
}

async function handleSimulatedResumeUpload(file) {
  const fileName = file.name;
  const fileSize = Math.round(file.size / 1024) + " KB";
  const today = new Date().toISOString().split("T")[0];

  // Try real Flask backend upload first
  if (typeof ApiClient !== "undefined") {
    try {
      showToast("Uploading resume to backend...");
      const res = await ApiClient.uploadResume(file);
      if (res && res.student) {
        StorageService.updateCurrentProfile(res.student);
        showToast(`Resume "${fileName}" uploaded & stored successfully!`);
        return;
      }
    } catch (err) {
      console.warn("Backend upload failed, using local fallback:", err.message);
    }
  }

  // Simulated extraction fallback
  const detectedSkills = [];
  SKILL_DATABASE.forEach(skill => {
    if (fileName.toLowerCase().includes(skill.toLowerCase())) {
      detectedSkills.push(skill);
    }
  });

  const student = StorageService.getCurrentProfile();
  const currentSkills = [...(student.skills || [])];

  detectedSkills.forEach(s => {
    if (!currentSkills.includes(s)) currentSkills.push(s);
  });

  StorageService.updateCurrentProfile({
    resumeFileName: fileName,
    resumeFileSize: fileSize,
    resumeUploadedAt: today,
    skills: currentSkills
  });

  showToast(`Uploaded ${fileName}! Resume score recalculated.`);
}

// -------------------------------------------------------------
// Eligibility Radar & Match Checker Tab
// -------------------------------------------------------------
function renderEligibilityRadar() {
  const container = document.getElementById("eligibility-radar-jobs");
  if (!container) return;

  const student = StorageService.getCurrentProfile();
  const jobs = StorageService.getAllJobs();

  container.innerHTML = jobs.map(job => {
    const evalResult = EligibilityEngine.evaluate(student, job);
    return `
      <div class="radar-item-row" onclick="openEligibilityModal('${job.id}')">
        <div class="radar-company-info">
          <div class="company-logo sm" style="background-color: ${job.logoBg || "#4F46E5"}">
            ${job.companyInitial || job.company[0]}
          </div>
          <div>
            <h4>${escapeHtml(job.title)}</h4>
            <span class="sub">${escapeHtml(job.company)} • Min CGPA: ${job.minCgpa}</span>
          </div>
        </div>

        <div class="radar-progress-bar-wrap">
          <div class="radar-meter">
            <div class="radar-fill ${evalResult.verdict.toLowerCase()}" style="width: ${evalResult.score}%"></div>
          </div>
          <span class="radar-score-text">${evalResult.score}% Match</span>
        </div>

        <div class="radar-verdict-badge ${evalResult.verdict.toLowerCase()}">
          ${evalResult.verdict}
        </div>

        <button class="btn btn-secondary btn-sm" onclick="event.stopPropagation(); openEligibilityModal('${job.id}')">
          View Audit
        </button>
      </div>
    `;
  }).join("");
}

// -------------------------------------------------------------
// Skill Gap & Insights Tab
// -------------------------------------------------------------
function renderInsights() {
  const container = document.getElementById("insights-top-skills");
  if (!container) return;

  const student = StorageService.getCurrentProfile();
  const jobs = StorageService.getAllJobs();

  const report = EligibilityEngine.generateSkillGapReport(student, jobs);

  if (report.topMissingSkills.length === 0) {
    container.innerHTML = `
      <div class="insights-congrats">
        <h4>🎉 Fantastic Job!</h4>
        <p>You have all the core skills currently in demand across our active listings.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = report.topMissingSkills.map(item => `
    <div class="skill-gap-card">
      <div class="gap-card-header">
        <h4>${escapeHtml(item.skill)}</h4>
        <button class="btn btn-primary btn-xs" onclick="addSkillToProfile('${item.skill}')">+ Add to Profile</button>
      </div>
      <p class="gap-card-demand">
        Required by <strong>${item.count} open roles</strong> (${item.percentage}% of all positions).
      </p>
      <div class="gap-sample-jobs">
        <span>Examples: ${item.sampleJobs.join(", ")}</span>
      </div>
    </div>
  `).join("");
}

// -------------------------------------------------------------
// UI Utilities (Toast, SVG Icons, Formatting, Escaping)
// -------------------------------------------------------------
function showToast(message, type = "info") {
  let toastContainer = document.getElementById("toast-container");
  if (!toastContainer) {
    toastContainer = document.createElement("div");
    toastContainer.id = "toast-container";
    document.body.appendChild(toastContainer);
  }

  const toast = document.createElement("div");
  toast.className = `toast-item toast-${type}`;
  toast.innerHTML = `
    <span>${message}</span>
    <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
  `;
  toastContainer.appendChild(toast);

  setTimeout(() => {
    toast.classList.add("fade-out");
    setTimeout(() => toast.remove(), 400);
  }, 3500);
}

function formatDate(dateStr) {
  if (!dateStr) return "N/A";
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  } catch (e) {
    return dateStr;
  }
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function getSvgIcon(name) {
  const icons = {
    "search": `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>`,
    "map-pin": `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>`,
    "clock": `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>`,
    "bookmark": `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path></svg>`,
    "bookmark-filled": `<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path></svg>`,
    "check-circle": `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`,
    "alert-triangle": `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>`,
    "alert-circle": `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>`,
    "check": `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>`,
    "moon": `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>`,
    "sun": `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>`,
    "calendar": `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>`,
    "file-text": `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>`,
    "trash": `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>`,
    "zap": `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>`
  };
  return icons[name] || "";
}
