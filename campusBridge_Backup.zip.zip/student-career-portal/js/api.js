/**
 * CampusBridge - API Client Module
 * Connects frontend views directly to Python Flask REST endpoints.
 */

const ApiClient = {
  baseUrl: "/api",
  isBackendActive: true,

  async request(endpoint, options = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const defaultHeaders = {
      "Accept": "application/json"
    };

    if (!(options.body instanceof FormData)) {
      defaultHeaders["Content-Type"] = "application/json";
    }

    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          ...defaultHeaders,
          ...options.headers
        }
      });

      const data = await response.json().catch(() => null);

      if (!response.ok) {
        throw new Error((data && data.error) || `Request failed with status ${response.status}`);
      }

      this.isBackendActive = true;
      return data;
    } catch (err) {
      console.warn(`[ApiClient] Request to ${url} failed:`, err.message);
      throw err;
    }
  },

  // --- Auth & Student ---

  async getCurrentStudent() {
    const res = await this.request("/auth/me");
    return res && res.student;
  },

  async login(email, password) {
    const res = await this.request("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password })
    });
    return res && res.student;
  },

  async register(studentData) {
    const res = await this.request("/auth/register", {
      method: "POST",
      body: JSON.stringify(studentData)
    });
    return res && res.student;
  },

  async logout() {
    return await this.request("/auth/logout", { method: "POST" });
  },

  async getAllStudents() {
    const res = await this.request("/students");
    return (res && res.students) || [];
  },

  async switchStudent(studentId) {
    const res = await this.request("/students/switch", {
      method: "POST",
      body: JSON.stringify({ studentId })
    });
    return res && res.student;
  },

  async updateProfile(profileData) {
    const res = await this.request("/students/profile", {
      method: "PUT",
      body: JSON.stringify(profileData)
    });
    return res && res.student;
  },

  // --- Jobs ---

  async getJobs() {
    const res = await this.request("/jobs");
    return (res && res.jobs) || [];
  },

  async getJob(jobId) {
    const res = await this.request(`/jobs/${jobId}`);
    return res && res.job;
  },

  async postJob(jobData) {
    const res = await this.request("/jobs", {
      method: "POST",
      body: JSON.stringify(jobData)
    });
    return res && res.job;
  },

  async checkEligibility(jobId) {
    const res = await this.request(`/jobs/${jobId}/eligibility`);
    return res;
  },

  // --- Applications ---

  async getApplications() {
    const res = await this.request("/applications");
    return (res && res.applications) || [];
  },

  async submitApplication(jobId, coverNote, resumeUsed) {
    const res = await this.request("/applications", {
      method: "POST",
      body: JSON.stringify({ jobId, coverNote, resumeUsed })
    });
    return res && res.application;
  },

  async updateApplicationStatus(appId, status) {
    const res = await this.request(`/applications/${appId}/status`, {
      method: "PUT",
      body: JSON.stringify({ status })
    });
    return res && res.application;
  },

  async updateApplicationNotes(appId, notes) {
    const res = await this.request(`/applications/${appId}/notes`, {
      method: "PUT",
      body: JSON.stringify({ notes })
    });
    return res && res.application;
  },

  async withdrawApplication(appId) {
    return await this.request(`/applications/${appId}`, {
      method: "DELETE"
    });
  },

  // --- Resume Upload ---

  async uploadResume(file) {
    const formData = new FormData();
    formData.append("file", file);

    const res = await this.request("/resumes/upload", {
      method: "POST",
      body: formData
    });
    return res;
  },

  // --- Bookmarks ---

  async getBookmarks() {
    const res = await this.request("/bookmarks");
    return (res && res.bookmarks) || [];
  },

  async toggleBookmark(jobId) {
    const res = await this.request(`/bookmarks/${jobId}/toggle`, {
      method: "POST"
    });
    return res;
  },

  // --- Skill Gap Insights ---

  async getSkillGapReport() {
    const res = await this.request("/insights/skill-gap");
    return res && res.report;
  },

  async getEligibilityRadar() {
    const res = await this.request("/eligibility/radar");
    return (res && res.radar) || [];
  },

  async checkHealth() {
    return await this.request("/health");
  }
};
