/**
 * CampusBridge - Storage & State Management
 * Connects seamlessly to the Python Flask & SQLite backend with offline fallback.
 */

const STORAGE_KEYS = {
  CURRENT_PROFILE_ID: "cb_current_profile_id",
  PROFILES: "cb_profiles",
  JOBS: "cb_jobs",
  APPLICATIONS: "cb_applications",
  BOOKMARKS: "cb_bookmarks",
  THEME: "cb_theme"
};

const StorageService = {
  init() {
    if (!localStorage.getItem(STORAGE_KEYS.PROFILES)) {
      localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(INITIAL_PROFILES));
    }
    if (!localStorage.getItem(STORAGE_KEYS.CURRENT_PROFILE_ID)) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_PROFILE_ID, "student-1");
    }
    if (!localStorage.getItem(STORAGE_KEYS.JOBS)) {
      localStorage.setItem(STORAGE_KEYS.JOBS, JSON.stringify(INITIAL_JOBS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.APPLICATIONS)) {
      localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(INITIAL_APPLICATIONS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.BOOKMARKS)) {
      localStorage.setItem(STORAGE_KEYS.BOOKMARKS, JSON.stringify(["job-102", "job-104"]));
    }

    // Attempt initial synchronization with Flask backend
    this.syncWithBackend();
  },

  async syncWithBackend() {
    if (typeof ApiClient === "undefined") return;
    try {
      // 1. Sync current student
      const student = await ApiClient.getCurrentStudent();
      if (student) {
        let profiles = this.getAllProfiles();
        const idx = profiles.findIndex(p => p.id === student.id);
        if (idx !== -1) {
          profiles[idx] = student;
        } else {
          profiles.unshift(student);
        }
        localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(profiles));
        localStorage.setItem(STORAGE_KEYS.CURRENT_PROFILE_ID, student.id);
      }

      // 2. Sync all registered & demo students
      const allStudents = await ApiClient.getAllStudents();
      if (allStudents && allStudents.length > 0) {
        localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(allStudents));
      }

      // 3. Sync jobs
      const jobs = await ApiClient.getJobs();
      if (jobs && jobs.length > 0) {
        localStorage.setItem(STORAGE_KEYS.JOBS, JSON.stringify(jobs));
      }

      // 4. Sync applications
      const apps = await ApiClient.getApplications();
      if (apps) {
        localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));
      }

      // 5. Sync bookmarks
      const bookmarks = await ApiClient.getBookmarks();
      if (bookmarks) {
        localStorage.setItem(STORAGE_KEYS.BOOKMARKS, JSON.stringify(bookmarks));
      }

      window.dispatchEvent(new CustomEvent("campusbridge:backendSynced"));
    } catch (err) {
      console.warn("Operating with local storage state:", err.message);
    }
  },

  // --- Profiles ---
  getAllProfiles() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROFILES);
      return data ? JSON.parse(data) : INITIAL_PROFILES;
    } catch (e) {
      console.error("Error reading profiles:", e);
      return INITIAL_PROFILES;
    }
  },

  getCurrentProfile() {
    const profiles = this.getAllProfiles();
    const currentId = localStorage.getItem(STORAGE_KEYS.CURRENT_PROFILE_ID) || "student-1";
    const found = profiles.find(p => p.id === currentId);
    return found || (profiles.length > 0 ? profiles[0] : INITIAL_PROFILES[0]);
  },

  setCurrentProfileId(profileId) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_PROFILE_ID, profileId);
    window.dispatchEvent(new CustomEvent("campusbridge:profileChanged", { detail: { profileId } }));

    // Sync to backend session
    if (typeof ApiClient !== "undefined") {
      ApiClient.switchStudent(profileId).catch(err => {
        console.warn("Backend switch error:", err.message);
      });
    }
  },

  async updateCurrentProfile(updatedData) {
    const profiles = this.getAllProfiles();
    const currentId = this.getCurrentProfile().id;
    const index = profiles.findIndex(p => p.id === currentId);
    
    if (index !== -1) {
      profiles[index] = { ...profiles[index], ...updatedData };
      localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(profiles));
      window.dispatchEvent(new CustomEvent("campusbridge:profileUpdated", { detail: profiles[index] }));
    }

    // Persist to backend database
    if (typeof ApiClient !== "undefined") {
      try {
        const saved = await ApiClient.updateProfile(updatedData);
        if (saved) {
          profiles[index] = saved;
          localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(profiles));
        }
      } catch (err) {
        console.warn("Backend profile update failed:", err.message);
      }
    }

    return profiles[index];
  },

  // --- Authentication Helpers ---
  async login(email, password) {
    if (typeof ApiClient === "undefined") throw new Error("API Client not loaded");
    const student = await ApiClient.login(email, password);
    if (student) {
      const profiles = this.getAllProfiles();
      const idx = profiles.findIndex(p => p.id === student.id);
      if (idx !== -1) {
        profiles[idx] = student;
      } else {
        profiles.unshift(student);
      }
      localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(profiles));
      localStorage.setItem(STORAGE_KEYS.CURRENT_PROFILE_ID, student.id);
      window.dispatchEvent(new CustomEvent("campusbridge:profileChanged", { detail: { profileId: student.id } }));
      await this.syncWithBackend();
    }
    return student;
  },

  async register(studentData) {
    if (typeof ApiClient === "undefined") throw new Error("API Client not loaded");
    const student = await ApiClient.register(studentData);
    if (student) {
      const profiles = this.getAllProfiles();
      profiles.unshift(student);
      localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(profiles));
      localStorage.setItem(STORAGE_KEYS.CURRENT_PROFILE_ID, student.id);
      window.dispatchEvent(new CustomEvent("campusbridge:profileChanged", { detail: { profileId: student.id } }));
      await this.syncWithBackend();
    }
    return student;
  },

  async logout() {
    if (typeof ApiClient !== "undefined") {
      try {
        await ApiClient.logout();
      } catch (e) {}
    }
    // Default back to first demo student
    this.setCurrentProfileId("student-1");
  },

  // --- Jobs ---
  getAllJobs() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.JOBS);
      return data ? JSON.parse(data) : INITIAL_JOBS;
    } catch (e) {
      console.error("Error reading jobs:", e);
      return INITIAL_JOBS;
    }
  },

  getJobById(jobId) {
    const jobs = this.getAllJobs();
    return jobs.find(j => j.id === jobId) || null;
  },

  async addJob(newJob) {
    const jobs = this.getAllJobs();
    let createdJob = {
      ...newJob,
      id: "job-" + Date.now(),
      postedAt: new Date().toISOString().split("T")[0]
    };

    // Save in Flask database
    if (typeof ApiClient !== "undefined") {
      try {
        const backendJob = await ApiClient.postJob(newJob);
        if (backendJob) createdJob = backendJob;
      } catch (err) {
        console.warn("Backend job creation failed:", err.message);
      }
    }

    jobs.unshift(createdJob);
    localStorage.setItem(STORAGE_KEYS.JOBS, JSON.stringify(jobs));
    window.dispatchEvent(new CustomEvent("campusbridge:jobsUpdated"));
    return createdJob;
  },

  // --- Applications ---
  getAllApplications() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.APPLICATIONS);
      return data ? JSON.parse(data) : INITIAL_APPLICATIONS;
    } catch (e) {
      console.error("Error reading applications:", e);
      return INITIAL_APPLICATIONS;
    }
  },

  getApplicationsForCurrentStudent() {
    const currentProfile = this.getCurrentProfile();
    const allApps = this.getAllApplications();
    return allApps.filter(app => app.studentId === currentProfile.id);
  },

  hasStudentApplied(jobId) {
    const studentApps = this.getApplicationsForCurrentStudent();
    return studentApps.some(app => app.jobId === jobId);
  },

  async submitApplication({ jobId, coverNote, resumeUsed, matchScore }) {
    const currentProfile = this.getCurrentProfile();
    const job = this.getJobById(jobId);
    if (!job) throw new Error("Job not found");

    if (this.hasStudentApplied(jobId)) {
      throw new Error("You have already submitted an application for this role.");
    }

    const today = new Date().toISOString().split("T")[0];
    let newApp = {
      id: "app-" + Date.now(),
      studentId: currentProfile.id,
      jobId: job.id,
      jobTitle: job.title,
      company: job.company,
      status: "applied",
      appliedDate: today,
      resumeUsed: resumeUsed || currentProfile.resumeFileName || "Default_Resume.pdf",
      coverNote: coverNote || "",
      matchScore: matchScore || 0,
      timeline: [
        {
          date: today,
          title: "Application Submitted",
          detail: `Applied for ${job.title} at ${job.company} via CampusBridge.`
        }
      ],
      notes: ""
    };

    // Send to Flask backend
    if (typeof ApiClient !== "undefined") {
      try {
        const backendApp = await ApiClient.submitApplication(jobId, coverNote, newApp.resumeUsed);
        if (backendApp) newApp = backendApp;
      } catch (err) {
        console.warn("Backend application submit error:", err.message);
      }
    }

    const allApps = this.getAllApplications();
    allApps.unshift(newApp);
    localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(allApps));
    window.dispatchEvent(new CustomEvent("campusbridge:applicationsUpdated"));
    return newApp;
  },

  async updateApplicationStatus(appId, newStatus) {
    const allApps = this.getAllApplications();
    const target = allApps.find(a => a.id === appId);
    if (target) {
      const oldStatus = target.status;
      target.status = newStatus;
      const today = new Date().toISOString().split("T")[0];
      
      const statusLabels = {
        applied: "Application Received",
        reviewing: "Under Evaluation",
        interview: "Interview Round Scheduled",
        offer: "Congratulations! Offer Extended",
        rejected: "Application Concluded"
      };

      target.timeline.unshift({
        date: today,
        title: `Status updated to: ${statusLabels[newStatus] || newStatus}`,
        detail: `Moved from ${oldStatus} to ${newStatus}.`
      });

      localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(allApps));
      window.dispatchEvent(new CustomEvent("campusbridge:applicationsUpdated"));

      // Send to Flask backend
      if (typeof ApiClient !== "undefined") {
        try {
          await ApiClient.updateApplicationStatus(appId, newStatus);
        } catch (e) {
          console.warn("Backend status update error:", e.message);
        }
      }

      return target;
    }
    return null;
  },

  async updateApplicationNotes(appId, notes) {
    const allApps = this.getAllApplications();
    const target = allApps.find(a => a.id === appId);
    if (target) {
      target.notes = notes;
      localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(allApps));

      if (typeof ApiClient !== "undefined") {
        try {
          await ApiClient.updateApplicationNotes(appId, notes);
        } catch (e) {}
      }
      return target;
    }
    return null;
  },

  async withdrawApplication(appId) {
    let allApps = this.getAllApplications();
    allApps = allApps.filter(a => a.id !== appId);
    localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(allApps));
    window.dispatchEvent(new CustomEvent("campusbridge:applicationsUpdated"));

    if (typeof ApiClient !== "undefined") {
      try {
        await ApiClient.withdrawApplication(appId);
      } catch (e) {}
    }
  },

  // --- Bookmarks ---
  getBookmarks() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.BOOKMARKS);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  },

  isBookmarked(jobId) {
    const bookmarks = this.getBookmarks();
    return bookmarks.includes(jobId);
  },

  async toggleBookmark(jobId) {
    let bookmarks = this.getBookmarks();
    let isNowSaved = false;
    if (bookmarks.includes(jobId)) {
      bookmarks = bookmarks.filter(id => id !== jobId);
      isNowSaved = false;
    } else {
      bookmarks.push(jobId);
      isNowSaved = true;
    }
    localStorage.setItem(STORAGE_KEYS.BOOKMARKS, JSON.stringify(bookmarks));
    window.dispatchEvent(new CustomEvent("campusbridge:bookmarksUpdated"));

    if (typeof ApiClient !== "undefined") {
      try {
        await ApiClient.toggleBookmark(jobId);
      } catch (e) {}
    }
    return isNowSaved;
  },

  // --- Theme ---
  getTheme() {
    return localStorage.getItem(STORAGE_KEYS.THEME) || "light";
  },

  setTheme(theme) {
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
    document.documentElement.setAttribute("data-theme", theme);
  },

  // --- Reset All Data ---
  resetAllData() {
    localStorage.removeItem(STORAGE_KEYS.PROFILES);
    localStorage.removeItem(STORAGE_KEYS.CURRENT_PROFILE_ID);
    localStorage.removeItem(STORAGE_KEYS.JOBS);
    localStorage.removeItem(STORAGE_KEYS.APPLICATIONS);
    localStorage.removeItem(STORAGE_KEYS.BOOKMARKS);
    this.init();
    window.location.reload();
  }
};

// Initialize on script load
StorageService.init();
