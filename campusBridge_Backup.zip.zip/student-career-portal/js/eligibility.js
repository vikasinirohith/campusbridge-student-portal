/**
 * CampusBridge - Smart Eligibility & Matching Engine
 * Evaluates candidate eligibility based on CGPA cutoffs, required skills, and graduation year batches.
 */

const EligibilityEngine = {
  /**
   * Normalizes skill strings for reliable matching (e.g., "Node.js" -> "nodejs", "react" -> "react")
   */
  normalizeSkill(skill) {
    if (!skill) return "";
    return skill.toLowerCase().replace(/[^a-z0-9]/g, "");
  },

  /**
   * Check if candidate possesses a specific skill
   */
  hasSkill(studentSkills, targetSkill) {
    const normTarget = this.normalizeSkill(targetSkill);
    return studentSkills.some(s => {
      const normStudent = this.normalizeSkill(s);
      return normStudent === normTarget || normStudent.includes(normTarget) || normTarget.includes(normStudent);
    });
  },

  /**
   * Calculates detailed eligibility for a student against a job
   */
  evaluate(student, job) {
    if (!student || !job) {
      return {
        verdict: "INELIGIBLE",
        score: 0,
        cgpaPassed: false,
        cgpaGap: 0,
        batchPassed: false,
        matchedSkills: [],
        missingSkills: [],
        matchedPreferred: [],
        missingPreferred: [],
        skillMatchPct: 0,
        reasons: ["Missing student profile or job details."],
        recommendations: []
      };
    }

    const studentSkills = student.skills || [];
    const requiredSkills = job.requiredSkills || [];
    const preferredSkills = job.preferredSkills || [];

    // 1. CGPA evaluation
    const studentCgpa = parseFloat(student.cgpa) || 0;
    const minCgpa = parseFloat(job.minCgpa) || 0;
    const cgpaPassed = studentCgpa >= minCgpa;
    const cgpaGap = Math.round((studentCgpa - minCgpa) * 10) / 10;

    // 2. Batch / Graduation year evaluation
    const studentBatch = parseInt(student.gradYear, 10);
    const eligibleBatches = job.eligibleBatches || [];
    const batchPassed = eligibleBatches.length === 0 || eligibleBatches.includes(studentBatch);

    // 3. Skills matching
    const matchedSkills = [];
    const missingSkills = [];

    requiredSkills.forEach(req => {
      if (this.hasSkill(studentSkills, req)) {
        matchedSkills.push(req);
      } else {
        missingSkills.push(req);
      }
    });

    const matchedPreferred = [];
    const missingPreferred = [];
    preferredSkills.forEach(pref => {
      if (this.hasSkill(studentSkills, pref)) {
        matchedPreferred.push(pref);
      } else {
        missingPreferred.push(pref);
      }
    });

    const totalRequired = requiredSkills.length;
    const skillMatchPct = totalRequired > 0 
      ? Math.round((matchedSkills.length / totalRequired) * 100) 
      : 100;

    // 4. Calculate Comprehensive Match Score (0 - 100)
    let score = 0;

    // CGPA weight: 35 points
    if (cgpaPassed) {
      const bonus = Math.min(10, Math.max(0, (studentCgpa - minCgpa) * 5));
      score += 25 + bonus;
    } else {
      // Partial credit if close
      const penaltyRatio = Math.max(0, 1 - Math.abs(cgpaGap) / 2);
      score += Math.round(15 * penaltyRatio);
    }

    // Required Skills weight: 45 points
    if (totalRequired > 0) {
      score += Math.round((matchedSkills.length / totalRequired) * 45);
    } else {
      score += 45;
    }

    // Batch weight: 10 points
    if (batchPassed) {
      score += 10;
    }

    // Preferred Skills weight: 10 points
    if (preferredSkills.length > 0) {
      score += Math.round((matchedPreferred.length / preferredSkills.length) * 10);
    } else {
      score += 5;
    }

    score = Math.min(100, Math.max(5, Math.round(score)));

    // 5. Verdict determination
    let verdict = "ELIGIBLE"; // ELIGIBLE | PARTIAL | INELIGIBLE
    const reasons = [];
    const recommendations = [];

    if (!cgpaPassed) {
      reasons.push(`CGPA is ${studentCgpa}, which is below the minimum required ${minCgpa} (Gap: ${Math.abs(cgpaGap)} pts).`);
    } else {
      reasons.push(`Meets CGPA cutoff of ${minCgpa} (Your CGPA: ${studentCgpa}, +${cgpaGap}).`);
    }

    if (!batchPassed) {
      reasons.push(`Graduation batch ${studentBatch} is not among the eligible batches (${eligibleBatches.join(", ")}).`);
    } else if (eligibleBatches.length > 0) {
      reasons.push(`Graduation batch ${studentBatch} is eligible.`);
    }

    if (missingSkills.length > 0) {
      reasons.push(`Missing ${missingSkills.length} of ${totalRequired} required skills (${missingSkills.join(", ")}).`);
      recommendations.push(`Add or practice ${missingSkills.slice(0, 2).join(" & ")} to boost your match to 100%.`);
    } else {
      reasons.push(`Matches all ${totalRequired} mandatory skills!`);
    }

    // Classification
    if (cgpaPassed && batchPassed && skillMatchPct >= 60) {
      verdict = "ELIGIBLE";
    } else if (cgpaPassed && batchPassed && skillMatchPct >= 30) {
      verdict = "PARTIAL";
    } else if (skillMatchPct >= 75 && Math.abs(cgpaGap) <= 0.4 && batchPassed) {
      verdict = "PARTIAL"; // Strong skill set, minor CGPA margin
    } else {
      verdict = "INELIGIBLE";
    }

    return {
      verdict,
      score,
      cgpaPassed,
      cgpaGap,
      batchPassed,
      matchedSkills,
      missingSkills,
      matchedPreferred,
      missingPreferred,
      skillMatchPct,
      reasons,
      recommendations
    };
  },

  /**
   * Generates skill gap insights for the current student across all active jobs
   */
  generateSkillGapReport(student, jobs) {
    if (!student || !jobs || jobs.length === 0) {
      return { topMissingSkills: [], potentialUnlocks: [] };
    }

    const missingSkillCounts = {};
    const skillToJobsMap = {};

    jobs.forEach(job => {
      const evaluation = this.evaluate(student, job);
      evaluation.missingSkills.forEach(skill => {
        missingSkillCounts[skill] = (missingSkillCounts[skill] || 0) + 1;
        if (!skillToJobsMap[skill]) skillToJobsMap[skill] = [];
        skillToJobsMap[skill].push(job.title);
      });
    });

    const topMissingSkills = Object.entries(missingSkillCounts)
      .map(([skill, count]) => ({
        skill,
        count,
        percentage: Math.round((count / jobs.length) * 100),
        sampleJobs: (skillToJobsMap[skill] || []).slice(0, 3)
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 6);

    return {
      topMissingSkills,
      totalJobs: jobs.length
    };
  }
};
