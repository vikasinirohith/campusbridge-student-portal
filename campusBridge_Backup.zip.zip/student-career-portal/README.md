# CampusBridge — Student Career & Internship Portal

**CampusBridge** is a modern, responsive web application and full-stack platform designed specifically for college students and campus placement cells. It solves the critical challenge students face when searching for internships and entry-level positions: **knowing whether they are truly eligible before spending hours applying.**

Now powered by a **Python Flask backend** and **SQLite database**, CampusBridge combines an elegant, responsive frontend with database persistence, password hashing, session authentication, eligibility calculation, and real resume file management.

---

## 🌟 Key Features

### 1. 🔐 Student Authentication & Registration
- **Student Registration**: Register with name, college email, password, department (e.g. Computer Science, Data Science & AI), degree, graduation year, CGPA, and technical skills.
- **Secure Password Hashing**: Utilizes `werkzeug.security.generate_password_hash` with pbkdf2/scrypt.
- **Session-Based Authentication**: Maintains secure login sessions via `/api/auth/login`, `/api/auth/me`, and `/api/auth/logout`.
- **Pre-Loaded Demo Accounts**:
  - `alex.rivera@university.edu` / `password123` (CGPA 8.6, CS)
  - `priya.sharma@institute.ac.in` / `password123` (CGPA 9.2, AI/ML)
  - `m.chen@statecollege.edu` / `password123` (CGPA 7.4, Design)

### 2. 🎯 Real-Time Smart Eligibility & Matching Engine
- **Academic CGPA Cutoff Evaluation**: Compares cumulative CGPA against minimum cutoffs (e.g., 7.5, 8.0, 8.8) and calculates margin (+0.6 passed or deficit).
- **Skill Inventory Matching**: Performs normalized string matching between the student's skills and employer requirements, calculating an exact match percentage (e.g., 85% Match).
- **Cohort Batch Verification**: Validates whether the student's graduation year (2025, 2026, 2027) matches target cohorts.
- **Dynamic Eligibility Badges**:
  - 🟢 **Eligible**: Candidate meets or exceeds CGPA cutoff and matches >=60% of required skills.
  - 🟡 **Partial Match**: Candidate meets CGPA but has a skill gap (highlights missing technologies with 1-click advice).
  - 🔴 **Ineligible**: Candidate is below the cutoff or batch mismatch.
- **Interactive Breakdown Audit Modal**: Side-by-side comparison of requirements vs your credentials with actionable recommendations.

### 3. 💼 Comprehensive Job & Internship Search
- **12+ Verified Database Listings**: Pre-loaded across top employers including Stripe, Google Research, Atlassian, Figma, Microsoft Azure, Goldman Sachs, CrowdStrike, Tesla, Spotify, DoorDash, Uber, and Datadog.
- **Live Search & Multi-Filters**: Filter by keyword (role, company, tech stack), Job Type (Internship vs Full-time), Work Mode (Remote, Hybrid, On-Site), Field/Department, and **"Only Show Eligible For Me"** toggle.
- **Sorting Options**: Sort by Best Match Score, Highest Stipend/Salary, Recently Posted, or Deadline Approaching.
- **Bookmarks**: Save dream jobs to a dedicated saved list.

### 4. 📊 Application Pipeline & Tracking System (Kanban)
- Dedicated 5-stage application pipeline:
  1. **Applied**
  2. **Under Review**
  3. **Interview Scheduled**
  4. **Offer Received 🎉**
  5. **Not Selected**
- **Drag-and-Drop** or quick dropdown stage updates.
- Records resume used, match score at time of application, and allows personal interview preparation notes.
- Withdraw application option.

### 5. 📄 Real Resume Upload & ATS Scanner
- Accepts multipart file uploads (`.pdf`, `.doc`, `.docx`, `.txt`) via `POST /api/resumes/upload`.
- Saves uploaded files securely in the `uploads/` directory with generated safe timestamps.
- Direct download and preview access via `GET /uploads/<filename>`.
- Calculates ATS Resume Strength Score (0-100) with keyword optimization tips.

### 6. 📈 Skill Gap & Market Intelligence
- Cross-analyzes all active listings in SQLite against the active student's profile.
- Displays top missing skills most requested by campus recruiters (e.g., Docker, TypeScript, PyTorch) with 1-click "+ Add to Profile" buttons.

### 7. 🏢 Recruiter / Post Opportunity Mode
- Built-in form to publish custom internships or jobs with specific CGPA cutoffs, batch targets, stipends, and mandatory skills into SQLite.
- Instantly tests and ranks new listings against candidate credentials.

---

## 📁 Project Structure

```
student-career-portal/
├── app.py              # Flask server with REST API routes & static file serving
├── database.py         # SQLite schema, database connection & seed data
├── eligibility.py      # Backend eligibility evaluation algorithm & skill gap engine
├── campusbridge.db     # SQLite database (auto-generated)
├── requirements.txt    # Python dependencies (Flask, Werkzeug)
├── uploads/            # Storage directory for student uploaded resumes
├── index.html          # Semantic single-page application structure & modals
├── css/
│   └── styles.css      # Modern CSS custom properties, responsive grid, dark/light themes
├── js/
│   ├── api.js          # REST API client connecting frontend to Flask endpoints
│   ├── data.js         # Initial mock database & skills taxonomy
│   ├── storage.js      # State management with backend synchronization
│   ├── eligibility.js  # Client-side eligibility mirror
│   └── app.js          # UI controllers, modals, Kanban drag-and-drop, and filters
└── README.md           # Documentation
```

---

## 🔌 REST API Endpoints

### Authentication & Student Profile
| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `POST` | `/api/auth/register` | Register new student account with department, CGPA, skills |
| `POST` | `/api/auth/login` | Authenticate student with email and password |
| `POST` | `/api/auth/logout` | Terminate session |
| `GET` | `/api/auth/me` | Fetch active student session |
| `GET` | `/api/students` | List all students for demo switching |
| `POST` | `/api/students/switch` | Switch active demo student session |
| `PUT` | `/api/students/profile` | Update student profile, CGPA, and skills |

### Jobs & Eligibility
| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/jobs` | Get all jobs with calculated eligibility evaluations |
| `GET` | `/api/jobs/<id>` | Get single job details |
| `POST` | `/api/jobs` | Post a new job/internship (Recruiter mode) |
| `GET` | `/api/jobs/<id>/eligibility`| Run eligibility audit for current student |

### Applications & Tracking
| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/applications` | Get all applications for current student |
| `POST` | `/api/applications` | Apply for a job/internship |
| `PUT` | `/api/applications/<id>/status`| Update application pipeline stage |
| `PUT` | `/api/applications/<id>/notes` | Save interview prep notes |
| `DELETE`| `/api/applications/<id>` | Withdraw application |

### Resumes & Insights
| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `POST` | `/api/resumes/upload` | Upload resume file (`.pdf`, `.doc`, `.docx`, `.txt`) |
| `GET` | `/uploads/<filename>` | View / download uploaded resume file |
| `GET` | `/api/bookmarks` | Get bookmarked job IDs |
| `POST` | `/api/bookmarks/<id>/toggle` | Toggle job bookmark |
| `GET` | `/api/insights/skill-gap` | Calculate top missing skills across listings |

---

## 🚀 How to Run the Application

### 1. Install Dependencies
Ensure Python 3 is installed, then install Flask:
```bash
pip install -r requirements.txt
```

### 2. Start the Flask Backend Server
From the project root:
```bash
python app.py
```
By default, the server starts on **http://localhost:8080** (or your specified `PORT` environment variable).

### 3. Open in Browser
Open [**http://localhost:8080**](http://localhost:8080) in your web browser.

---

## 💡 How to Test the Features

1. **Student Login & Registration**:
   - Click the **"Sign In / Register"** button in the header.
   - Click **"Sign In"** using the prefilled demo credentials (`alex.rivera@university.edu` / `password123`) or switch to the **"Register New Student"** tab to register a new account.
2. **Eligibility Checking**:
   - Switch between **Alex Rivera** (CGPA 8.6) and **Priya Sharma** (CGPA 9.2).
   - Watch the eligibility badges recalculate across all cards in real time.
   - Click **"Breakdown »"** on any job card to view the cutoff comparison.
3. **Applying & Application Tracking**:
   - Click **"Apply Now"** on any job card to submit an application.
   - Navigate to the **Application Tracker** tab to drag applications between stages (*Applied ➔ Reviewing ➔ Interview ➔ Offer*).
4. **Resume Upload**:
   - Navigate to the **My Profile & Resume** tab.
   - Drag and drop or browse for a resume file. The file is uploaded to the backend `uploads/` folder and an immediate view/download link appears.
