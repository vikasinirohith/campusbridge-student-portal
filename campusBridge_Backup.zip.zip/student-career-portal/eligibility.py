"""
CampusBridge Eligibility Engine (Python Backend)
Evaluates student eligibility against job requirements based on:
1. Cumulative CGPA cutoff
2. Mandatory & preferred technical skill match
3. Graduation batch/year eligibility
"""

import re

def normalize_skill(skill):
    if not skill:
        return ""
    return re.sub(r'[^a-z0-9]', '', str(skill).lower())

def has_skill(student_skills, target_skill):
    norm_target = normalize_skill(target_skill)
    if not norm_target:
        return False
    for s in student_skills:
        norm_s = normalize_skill(s)
        if norm_s == norm_target or norm_s in norm_target or norm_target in norm_s:
            return True
    return False

def evaluate_eligibility(student, job):
    """
    Evaluates candidate compatibility with a job.
    Returns verdict, score, breakdown of matched/missing skills, and recommendations.
    """
    if not student or not job:
        return {
            "verdict": "INELIGIBLE",
            "score": 0,
            "cgpaPassed": False,
            "cgpaGap": 0,
            "batchPassed": False,
            "matchedSkills": [],
            "missingSkills": [],
            "matchedPreferred": [],
            "missingPreferred": [],
            "skillMatchPct": 0,
            "reasons": ["Missing student profile or job parameters."],
            "recommendations": []
        }

    student_skills = student.get("skills") or []
    required_skills = job.get("requiredSkills") or job.get("required_skills") or []
    preferred_skills = job.get("preferredSkills") or job.get("preferred_skills") or []

    # 1. CGPA evaluation
    try:
        student_cgpa = float(student.get("cgpa", 0))
    except (ValueError, TypeError):
        student_cgpa = 0.0

    try:
        min_cgpa = float(job.get("minCgpa") or job.get("min_cgpa") or 0)
    except (ValueError, TypeError):
        min_cgpa = 0.0

    cgpa_passed = student_cgpa >= min_cgpa
    cgpa_gap = round(student_cgpa - min_cgpa, 1)

    # 2. Batch evaluation
    try:
        student_batch = int(student.get("gradYear") or student.get("grad_year") or 0)
    except (ValueError, TypeError):
        student_batch = 0

    eligible_batches = job.get("eligibleBatches") or job.get("eligible_batches") or []
    batch_passed = len(eligible_batches) == 0 or student_batch in eligible_batches

    # 3. Skills matching
    matched_skills = []
    missing_skills = []
    for req in required_skills:
        if has_skill(student_skills, req):
            matched_skills.append(req)
        else:
            missing_skills.append(req)

    matched_preferred = []
    missing_preferred = []
    for pref in preferred_skills:
        if has_skill(student_skills, pref):
            matched_preferred.append(pref)
        else:
            missing_preferred.append(pref)

    total_required = len(required_skills)
    skill_match_pct = round((len(matched_skills) / total_required) * 100) if total_required > 0 else 100

    # 4. Score calculation (0 - 100)
    score = 0

    # CGPA weight: 35 points
    if cgpa_passed:
        bonus = min(10, max(0, (student_cgpa - min_cgpa) * 5))
        score += 25 + bonus
    else:
        penalty_ratio = max(0, 1 - abs(cgpa_gap) / 2)
        score += round(15 * penalty_ratio)

    # Required Skills weight: 45 points
    if total_required > 0:
        score += round((len(matched_skills) / total_required) * 45)
    else:
        score += 45

    # Batch weight: 10 points
    if batch_passed:
        score += 10

    # Preferred Skills weight: 10 points
    if preferred_skills:
        score += round((len(matched_preferred) / len(preferred_skills)) * 10)
    else:
        score += 5

    score = min(100, max(5, round(score)))

    # 5. Verdict
    if cgpa_passed and batch_passed and skill_match_pct >= 60:
        verdict = "ELIGIBLE"
    elif cgpa_passed and batch_passed and skill_match_pct >= 30:
        verdict = "PARTIAL"
    elif skill_match_pct >= 75 and abs(cgpa_gap) <= 0.4 and batch_passed:
        verdict = "PARTIAL"
    else:
        verdict = "INELIGIBLE"

    reasons = []
    recommendations = []

    if not cgpa_passed:
        reasons.append(f"CGPA is {student_cgpa}, which is below the minimum required {min_cgpa} (Gap: {abs(cgpa_gap)} pts).")
    else:
        reasons.append(f"Meets CGPA cutoff of {min_cgpa} (Your CGPA: {student_cgpa}, +{cgpa_gap}).")

    if not batch_passed:
        reasons.append(f"Graduation batch {student_batch} is not among eligible batches ({', '.join(map(str, eligible_batches))}).")
    elif eligible_batches:
        reasons.append(f"Graduation batch {student_batch} is eligible.")

    if missing_skills:
        reasons.append(f"Missing {len(missing_skills)} of {total_required} required skills ({', '.join(missing_skills)}).")
        recommendations.append(f"Add or practice {' & '.join(missing_skills[:2])} to boost your match to 100%.")
    else:
        reasons.append(f"Matches all {total_required} mandatory skills!")

    return {
        "verdict": verdict,
        "score": score,
        "cgpaPassed": cgpa_passed,
        "cgpaGap": cgpa_gap,
        "batchPassed": batch_passed,
        "matchedSkills": matched_skills,
        "missingSkills": missing_skills,
        "matchedPreferred": matched_preferred,
        "missingPreferred": missing_preferred,
        "skillMatchPct": skill_match_pct,
        "reasons": reasons,
        "recommendations": recommendations
    }

def generate_skill_gap_report(student, jobs):
    """Calculates top missing skills across all active positions."""
    if not student or not jobs:
        return {"topMissingSkills": [], "totalJobs": 0}

    missing_counts = {}
    skill_jobs = {}

    for job in jobs:
        ev = evaluate_eligibility(student, job)
        for s in ev["missingSkills"]:
            missing_counts[s] = missing_counts.get(s, 0) + 1
            if s not in skill_jobs:
                skill_jobs[s] = []
            skill_jobs[s].append(job.get("title", ""))

    top_missing = []
    for s, cnt in sorted(missing_counts.items(), key=lambda x: x[1], reverse=True)[:6]:
        top_missing.append({
            "skill": s,
            "count": cnt,
            "percentage": round((cnt / len(jobs)) * 100),
            "sampleJobs": skill_jobs[s][:3]
        })

    return {
        "topMissingSkills": top_missing,
        "totalJobs": len(jobs)
    }
