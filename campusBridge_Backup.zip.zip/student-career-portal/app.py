"""
CampusBridge Flask Application
Provides RESTful APIs for authentication, student profile, job matching,
eligibility checks, application pipeline tracking, and resume uploads.
"""

import os
import json
import sqlite3
from datetime import datetime
from flask import Flask, request, jsonify, session, send_from_directory
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

from database import (
    get_db, init_db, student_to_dict, job_to_dict, application_to_dict
)
from eligibility import evaluate_eligibility, generate_skill_gap_report

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOADS_FOLDER = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOADS_FOLDER, exist_ok=True)

ALLOWED_EXTENSIONS = {"pdf", "doc", "docx", "txt"}

app = Flask(__name__, static_folder=".", static_url_path="")
app.secret_key = "campusbridge-secret-key-change-in-prod-xyz123"
app.config["UPLOAD_FOLDER"] = UPLOADS_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16 MB max
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_HTTPONLY"] = True

# Initialize database on startup
init_db()

@app.after_request
def add_cors_headers(response):
    origin = request.headers.get("Origin")
    if origin:
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Access-Control-Allow-Credentials"] = "true"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, X-Requested-With"
    return response

@app.route("/api/<path:path>", methods=["OPTIONS"])
def handle_options(path):
    response = app.make_default_options_response()
    origin = request.headers.get("Origin")
    if origin:
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Access-Control-Allow-Credentials"] = "true"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, X-Requested-With"
    return response

@app.route("/api/health", methods=["GET"])
def health_check():
    return jsonify({
        "status": "healthy",
        "service": "CampusBridge Backend",
        "database": "SQLite connected",
        "timestamp": datetime.now().isoformat()
    })

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def get_current_student():
    """Helper to get current active student based on session or fallback to default student-1."""
    conn = get_db()
    cursor = conn.cursor()
    student_id = session.get("student_id", "student-1")
    cursor.execute("SELECT * FROM students WHERE id = ?", (student_id,))
    row = cursor.fetchone()
    if not row:
        # Fallback to first student in db
        cursor.execute("SELECT * FROM students LIMIT 1")
        row = cursor.fetchone()
        if row:
            session["student_id"] = row["id"]
    conn.close()
    return student_to_dict(row)

# -----------------------------------------------------------------------------
# Static & Frontend Serving
# -----------------------------------------------------------------------------

@app.route("/")
def index():
    return send_from_directory(".", "index.html")

@app.route("/uploads/<path:filename>")
def serve_upload(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)

# -----------------------------------------------------------------------------
# 1. Authentication & Student Endpoints
# -----------------------------------------------------------------------------

@app.route("/api/auth/register", methods=["POST"])
def register():
    data = request.get_json() or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    name = data.get("name", "").strip()

    if not email or not password or not name:
        return jsonify({"success": False, "error": "Name, email, and password are required"}), 400

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("SELECT id FROM students WHERE LOWER(email) = ?", (email,))
    if cursor.fetchone():
        conn.close()
        return jsonify({"success": False, "error": "An account with this email already exists"}), 409

    student_id = "student-" + str(int(datetime.now().timestamp()))
    pw_hash = generate_password_hash(password)
    department = data.get("department", "Computer Science").strip()
    degree = data.get("degree", "B.Tech Computer Science").strip()
    grad_year = int(data.get("gradYear") or data.get("grad_year") or 2026)
    cgpa = float(data.get("cgpa", 8.0))
    phone = data.get("phone", "").strip()
    bio = data.get("bio", "").strip()

    raw_skills = data.get("skills", ["JavaScript", "Python", "SQL"])
    if isinstance(raw_skills, str):
        skills_list = [s.strip() for s in raw_skills.split(",") if s.strip()]
    else:
        skills_list = list(raw_skills)

    cursor.execute("""
        INSERT INTO students (
            id, name, email, password_hash, phone, university, department, degree,
            grad_year, cgpa, skills, bio
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        student_id, name, email, pw_hash, phone,
        data.get("university", "University Campus").strip(),
        department, degree, grad_year, cgpa,
        json.dumps(skills_list), bio
    ))
    conn.commit()

    cursor.execute("SELECT * FROM students WHERE id = ?", (student_id,))
    new_student = student_to_dict(cursor.fetchone())
    conn.close()

    session["student_id"] = student_id
    return jsonify({"success": True, "student": new_student}), 201

@app.route("/api/auth/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or request.form.to_dict() or {}
    raw_ident = data.get("email") or data.get("username") or data.get("name") or ""
    ident = str(raw_ident).strip().lower()
    password = str(data.get("password", ""))

    if not ident or not password:
        return jsonify({"success": False, "error": "Email/Username and password are required"}), 400

    conn = get_db()
    cursor = conn.cursor()
    # Flexible lookup by email, name, student ID, or email prefix
    cursor.execute("""
        SELECT * FROM students 
        WHERE LOWER(TRIM(email)) = ? 
           OR LOWER(TRIM(name)) = ? 
           OR LOWER(TRIM(id)) = ?
           OR LOWER(TRIM(email)) LIKE ?
        LIMIT 1
    """, (ident, ident, ident, f"{ident}@%"))
    row = cursor.fetchone()
    conn.close()

    if not row:
        return jsonify({"success": False, "error": f"No student account found matching '{raw_ident.strip()}'. Use demo: alex.rivera@university.edu"}), 401

    # Verify password with whitespace tolerance
    is_valid = False
    stored_hash = row["password_hash"]
    if stored_hash:
        try:
            if check_password_hash(stored_hash, password) or check_password_hash(stored_hash, password.strip()):
                is_valid = True
        except Exception as e:
            print("[Auth Error] check_password_hash exception:", e)

    # For demo students (student-1, student-2, student-3), accept standard demo variants
    demo_passwords = {"password123", "password", "student123", "admin", "123456"}
    if not is_valid and row["id"] in {"student-1", "student-2", "student-3"}:
        if password in demo_passwords or password.strip() in demo_passwords:
            is_valid = True
            # Rehash with current generator for consistency
            try:
                c2 = get_db()
                new_hash = generate_password_hash("password123")
                c2.execute("UPDATE students SET password_hash = ? WHERE id = ?", (new_hash, row["id"]))
                c2.commit()
                c2.close()
            except Exception:
                pass

    if not is_valid:
        return jsonify({"success": False, "error": "Invalid password. For demo accounts use: password123"}), 401

    session["student_id"] = row["id"]
    return jsonify({"success": True, "student": student_to_dict(row)})

@app.route("/api/auth/logout", methods=["POST"])
def logout():
    session.pop("student_id", None)
    return jsonify({"success": True, "message": "Logged out successfully"})

@app.route("/api/auth/me", methods=["GET"])
def get_current_user():
    student = get_current_student()
    if not student:
        return jsonify({"success": False, "error": "No student profile active"}), 404
    return jsonify({"success": True, "student": student})

@app.route("/api/students", methods=["GET"])
def get_all_students():
    """List all demo / registered students for easy switcher in UI."""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM students ORDER BY name ASC")
    rows = cursor.fetchall()
    conn.close()
    return jsonify({"success": True, "students": [student_to_dict(r) for r in rows]})

@app.route("/api/students/switch", methods=["POST"])
def switch_student():
    """Switch active student profile (for testing/demo purposes)."""
    data = request.get_json() or {}
    student_id = data.get("studentId") or data.get("student_id")
    if not student_id:
        return jsonify({"success": False, "error": "studentId required"}), 400

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM students WHERE id = ?", (student_id,))
    row = cursor.fetchone()
    conn.close()

    if not row:
        return jsonify({"success": False, "error": "Student not found"}), 404

    session["student_id"] = row["id"]
    return jsonify({"success": True, "student": student_to_dict(row)})

@app.route("/api/students/profile", methods=["PUT"])
def update_profile():
    student = get_current_student()
    if not student:
        return jsonify({"success": False, "error": "Not authenticated"}), 401

    data = request.get_json() or {}
    conn = get_db()
    cursor = conn.cursor()

    name = data.get("name", student["name"]).strip()
    email = data.get("email", student["email"]).strip()
    phone = data.get("phone", student.get("phone", "")).strip()
    university = data.get("university", student.get("university", "")).strip()
    department = data.get("department", student.get("department", "Computer Science")).strip()
    degree = data.get("degree", student.get("degree", "")).strip()
    grad_year = int(data.get("gradYear") or data.get("grad_year") or student.get("gradYear", 2026))
    cgpa = float(data.get("cgpa", student.get("cgpa", 8.0)))
    bio = data.get("bio", student.get("bio", "")).strip()

    skills = data.get("skills", student.get("skills", []))
    if isinstance(skills, str):
        skills_json = json.dumps([s.strip() for s in skills.split(",") if s.strip()])
    else:
        skills_json = json.dumps(list(skills))

    cursor.execute("""
        UPDATE students SET
            name = ?, email = ?, phone = ?, university = ?, department = ?,
            degree = ?, grad_year = ?, cgpa = ?, skills = ?, bio = ?
        WHERE id = ?
    """, (name, email, phone, university, department, degree, grad_year, cgpa, skills_json, bio, student["id"]))
    conn.commit()

    cursor.execute("SELECT * FROM students WHERE id = ?", (student["id"],))
    updated = student_to_dict(cursor.fetchone())
    conn.close()

    return jsonify({"success": True, "student": updated})

# -----------------------------------------------------------------------------
# 2. Jobs & Eligibility Endpoints
# -----------------------------------------------------------------------------

@app.route("/api/jobs", methods=["GET"])
def get_jobs():
    student = get_current_student()
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM jobs ORDER BY posted_at DESC")
    rows = cursor.fetchall()
    conn.close()

    jobs_list = []
    for r in rows:
        job = job_to_dict(r)
        if student:
            job["evaluation"] = evaluate_eligibility(student, job)
        jobs_list.append(job)

    return jsonify({"success": True, "jobs": jobs_list})

@app.route("/api/jobs/<job_id>", methods=["GET"])
def get_single_job(job_id):
    student = get_current_student()
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM jobs WHERE id = ?", (job_id,))
    row = cursor.fetchone()
    conn.close()

    if not row:
        return jsonify({"success": False, "error": "Job not found"}), 404

    job = job_to_dict(row)
    if student:
        job["evaluation"] = evaluate_eligibility(student, job)
    return jsonify({"success": True, "job": job})

@app.route("/api/jobs", methods=["POST"])
def post_job():
    """Recruiter / Employer mode to add an opportunity."""
    data = request.get_json() or {}
    title = data.get("title", "").strip()
    company = data.get("company", "").strip()

    if not title or not company:
        return jsonify({"success": False, "error": "Job title and company are required"}), 400

    job_id = "job-" + str(int(datetime.now().timestamp()))
    today = datetime.now().strftime("%Y-%m-%d")

    req_skills = data.get("requiredSkills") or data.get("required_skills") or []
    if isinstance(req_skills, str):
        req_skills = [s.strip() for s in req_skills.split(",") if s.strip()]

    pref_skills = data.get("preferredSkills") or data.get("preferred_skills") or ["Git"]
    if isinstance(pref_skills, str):
        pref_skills = [s.strip() for s in pref_skills.split(",") if s.strip()]

    batches = data.get("eligibleBatches") or data.get("eligible_batches") or [2025, 2026, 2027]
    if isinstance(batches, str):
        batches = [int(b.strip()) for b in batches.split(",") if b.strip().isdigit()]

    stipend_num = data.get("stipendNumeric") or 5000
    try:
        stipend_num = float(stipend_num)
    except Exception:
        stipend_num = 5000

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO jobs (
            id, title, company, logo_bg, company_initial, type, work_mode, location,
            department, stipend, stipend_numeric, duration, min_cgpa, eligible_batches,
            required_skills, preferred_skills, deadline, description, openings, posted_at, featured
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        job_id, title, company,
        data.get("logoBg", "#059669"),
        company[0].upper() if company else "C",
        data.get("type", "Internship"),
        data.get("workMode", "Hybrid"),
        data.get("location", "Remote"),
        data.get("department", "Software Engineering"),
        data.get("stipend", "$5,000 / month"),
        stipend_num,
        data.get("duration", "12 Weeks"),
        float(data.get("minCgpa", 7.5)),
        json.dumps(batches),
        json.dumps(req_skills),
        json.dumps(pref_skills),
        data.get("deadline", "2026-12-31"),
        data.get("description", "Exciting campus internship opportunity."),
        int(data.get("openings", 3)),
        today,
        0
    ))
    conn.commit()

    cursor.execute("SELECT * FROM jobs WHERE id = ?", (job_id,))
    new_job = job_to_dict(cursor.fetchone())
    conn.close()

    return jsonify({"success": True, "job": new_job}), 201

@app.route("/api/jobs/<job_id>/eligibility", methods=["GET"])
def check_job_eligibility(job_id):
    student = get_current_student()
    if not student:
        return jsonify({"success": False, "error": "Not authenticated"}), 401

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM jobs WHERE id = ?", (job_id,))
    row = cursor.fetchone()
    conn.close()

    if not row:
        return jsonify({"success": False, "error": "Job not found"}), 404

    job = job_to_dict(row)
    evaluation = evaluate_eligibility(student, job)
    return jsonify({"success": True, "evaluation": evaluation, "job": job})

# -----------------------------------------------------------------------------
# 3. Application Pipeline & Tracking Endpoints
# -----------------------------------------------------------------------------

@app.route("/api/applications", methods=["GET"])
def get_applications():
    student = get_current_student()
    if not student:
        return jsonify({"success": True, "applications": []})

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM applications WHERE student_id = ? ORDER BY applied_date DESC", (student["id"],))
    rows = cursor.fetchall()
    conn.close()

    return jsonify({"success": True, "applications": [application_to_dict(r) for r in rows]})

@app.route("/api/applications", methods=["POST"])
def submit_application():
    student = get_current_student()
    if not student:
        return jsonify({"success": False, "error": "Not authenticated"}), 401

    data = request.get_json() or {}
    job_id = data.get("jobId") or data.get("job_id")
    if not job_id:
        return jsonify({"success": False, "error": "jobId required"}), 400

    conn = get_db()
    cursor = conn.cursor()

    # Check for duplicate
    cursor.execute("SELECT id FROM applications WHERE student_id = ? AND job_id = ?", (student["id"], job_id))
    if cursor.fetchone():
        conn.close()
        return jsonify({"success": False, "error": "You have already submitted an application for this role."}), 400

    # Get job info
    cursor.execute("SELECT * FROM jobs WHERE id = ?", (job_id,))
    job_row = cursor.fetchone()
    if not job_row:
        conn.close()
        return jsonify({"success": False, "error": "Job not found"}), 404

    job = job_to_dict(job_row)
    eval_result = evaluate_eligibility(student, job)

    app_id = "app-" + str(int(datetime.now().timestamp()))
    today = datetime.now().strftime("%Y-%m-%d")
    resume_used = data.get("resumeUsed") or student.get("resumeFileName") or "Student_Resume.pdf"
    cover_note = data.get("coverNote", "").strip()

    initial_timeline = [
        {
            "date": today,
            "title": "Application Submitted",
            "detail": f"Applied for {job['title']} at {job['company']} via CampusBridge."
        }
    ]

    cursor.execute("""
        INSERT INTO applications (
            id, student_id, job_id, job_title, company, status, applied_date,
            resume_used, cover_note, match_score, timeline, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        app_id, student["id"], job["id"], job["title"], job["company"],
        "applied", today, resume_used, cover_note, eval_result["score"],
        json.dumps(initial_timeline), ""
    ))
    conn.commit()

    cursor.execute("SELECT * FROM applications WHERE id = ?", (app_id,))
    new_app = application_to_dict(cursor.fetchone())
    conn.close()

    return jsonify({"success": True, "application": new_app}), 201

@app.route("/api/applications/<app_id>/status", methods=["PUT"])
def update_application_status(app_id):
    student = get_current_student()
    if not student:
        return jsonify({"success": False, "error": "Not authenticated"}), 401

    data = request.get_json() or {}
    new_status = data.get("status")
    if not new_status:
        return jsonify({"success": False, "error": "Status required"}), 400

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM applications WHERE id = ? AND student_id = ?", (app_id, student["id"]))
    row = cursor.fetchone()

    if not row:
        conn.close()
        return jsonify({"success": False, "error": "Application not found"}), 404

    current_app = application_to_dict(row)
    timeline = current_app.get("timeline") or []
    today = datetime.now().strftime("%Y-%m-%d")

    status_labels = {
        "applied": "Application Received",
        "reviewing": "Under Evaluation",
        "interview": "Interview Round Scheduled",
        "offer": "Congratulations! Offer Extended",
        "rejected": "Application Concluded"
    }

    timeline.insert(0, {
        "date": today,
        "title": f"Status updated to: {status_labels.get(new_status, new_status)}",
        "detail": f"Moved from {current_app.get('status')} to {new_status}."
    })

    cursor.execute("""
        UPDATE applications SET status = ?, timeline = ? WHERE id = ?
    """, (new_status, json.dumps(timeline), app_id))
    conn.commit()

    cursor.execute("SELECT * FROM applications WHERE id = ?", (app_id,))
    updated = application_to_dict(cursor.fetchone())
    conn.close()

    return jsonify({"success": True, "application": updated})

@app.route("/api/applications/<app_id>/notes", methods=["PUT"])
def update_application_notes(app_id):
    student = get_current_student()
    if not student:
        return jsonify({"success": False, "error": "Not authenticated"}), 401

    data = request.get_json() or {}
    notes = data.get("notes", "")

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE applications SET notes = ? WHERE id = ? AND student_id = ?
    """, (notes, app_id, student["id"]))
    conn.commit()

    cursor.execute("SELECT * FROM applications WHERE id = ?", (app_id,))
    updated = application_to_dict(cursor.fetchone())
    conn.close()

    return jsonify({"success": True, "application": updated})

@app.route("/api/applications/<app_id>", methods=["DELETE"])
def withdraw_application(app_id):
    student = get_current_student()
    if not student:
        return jsonify({"success": False, "error": "Not authenticated"}), 401

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM applications WHERE id = ? AND student_id = ?", (app_id, student["id"]))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": "Application withdrawn successfully"})

# -----------------------------------------------------------------------------
# 4. Resume Upload Endpoint
# -----------------------------------------------------------------------------

@app.route("/api/resumes/upload", methods=["POST"])
def upload_resume():
    student = get_current_student()
    if not student:
        return jsonify({"success": False, "error": "Not authenticated"}), 401

    if "file" not in request.files:
        return jsonify({"success": False, "error": "No file uploaded"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"success": False, "error": "Empty filename"}), 400

    if not allowed_file(file.filename):
        return jsonify({"success": False, "error": "File type not allowed (Allowed: .pdf, .doc, .docx, .txt)"}), 400

    original_filename = secure_filename(file.filename)
    timestamp = int(datetime.now().timestamp())
    saved_filename = f"{student['id']}_{timestamp}_{original_filename}"
    file_path = os.path.join(app.config["UPLOAD_FOLDER"], saved_filename)
    file.save(file_path)

    file_size_kb = f"{round(os.path.getsize(file_path) / 1024)} KB"
    today = datetime.now().strftime("%Y-%m-%d")

    # Simple keyword detection from filename / text
    detected_skills = []
    from eligibility import normalize_skill
    popular_skills = [
        "JavaScript", "TypeScript", "Python", "React", "Node.js", "SQL", "Docker",
        "AWS", "Git", "Figma", "Machine Learning", "C++", "Java", "Tableau", "PyTorch"
    ]
    for skill in popular_skills:
        if normalize_skill(skill) in normalize_skill(original_filename):
            detected_skills.append(skill)

    current_skills = list(student.get("skills", []))
    for s in detected_skills:
        if s not in current_skills:
            current_skills.append(s)

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE students SET
            resume_filename = ?, resume_filesize = ?, resume_uploaded_at = ?, skills = ?
        WHERE id = ?
    """, (original_filename, file_size_kb, today, json.dumps(current_skills), student["id"]))
    conn.commit()

    cursor.execute("SELECT * FROM students WHERE id = ?", (student["id"],))
    updated_student = student_to_dict(cursor.fetchone())
    conn.close()

    return jsonify({
        "success": True,
        "filename": original_filename,
        "filesize": file_size_kb,
        "uploadedAt": today,
        "url": f"/uploads/{saved_filename}",
        "detectedSkills": detected_skills,
        "student": updated_student
    })

# -----------------------------------------------------------------------------
# 5. Bookmarks Endpoints
# -----------------------------------------------------------------------------

@app.route("/api/bookmarks", methods=["GET"])
def get_bookmarks():
    student = get_current_student()
    if not student:
        return jsonify({"success": True, "bookmarks": []})

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT job_id FROM bookmarks WHERE student_id = ?", (student["id"],))
    rows = cursor.fetchall()
    conn.close()

    return jsonify({"success": True, "bookmarks": [r["job_id"] for r in rows]})

@app.route("/api/bookmarks/<job_id>/toggle", methods=["POST"])
def toggle_bookmark(job_id):
    student = get_current_student()
    if not student:
        return jsonify({"success": False, "error": "Not authenticated"}), 401

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM bookmarks WHERE student_id = ? AND job_id = ?", (student["id"], job_id))
    existing = cursor.fetchone()

    saved = False
    if existing:
        cursor.execute("DELETE FROM bookmarks WHERE student_id = ? AND job_id = ?", (student["id"], job_id))
        saved = False
    else:
        cursor.execute("INSERT INTO bookmarks (student_id, job_id) VALUES (?, ?)", (student["id"], job_id))
        saved = True

    conn.commit()

    cursor.execute("SELECT job_id FROM bookmarks WHERE student_id = ?", (student["id"],))
    all_bm = [r["job_id"] for r in cursor.fetchall()]
    conn.close()

    return jsonify({"success": True, "saved": saved, "bookmarks": all_bm})

# -----------------------------------------------------------------------------
# 6. Skill Gap & Insights Endpoint
# -----------------------------------------------------------------------------

@app.route("/api/insights/skill-gap", methods=["GET"])
def get_skill_gap():
    student = get_current_student()
    if not student:
        return jsonify({"success": True, "report": {"topMissingSkills": [], "totalJobs": 0}})

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM jobs")
    jobs = [job_to_dict(r) for r in cursor.fetchall()]
    conn.close()

    report = generate_skill_gap_report(student, jobs)
    return jsonify({"success": True, "report": report})

@app.route("/api/eligibility/radar", methods=["GET"])
def get_eligibility_radar():
    student = get_current_student()
    if not student:
        return jsonify({"success": False, "error": "Not authenticated"}), 401

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM jobs ORDER BY posted_at DESC")
    rows = cursor.fetchall()
    conn.close()

    radar_data = []
    for r in rows:
        job = job_to_dict(r)
        eval_res = evaluate_eligibility(student, job)
        radar_data.append({
            "job": job,
            "evaluation": eval_res
        })
    return jsonify({"success": True, "radar": radar_data})

# -----------------------------------------------------------------------------
# Error Handlers & Fallbacks
# -----------------------------------------------------------------------------

@app.errorhandler(404)
def handle_404(e):
    if request.path.startswith("/api/"):
        return jsonify({"success": False, "error": "Endpoint not found"}), 404
    return send_from_directory(".", "index.html")

@app.errorhandler(500)
def handle_500(e):
    return jsonify({"success": False, "error": "Internal server error"}), 500

# -----------------------------------------------------------------------------
# Entry Point
# -----------------------------------------------------------------------------

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    print(f"Starting CampusBridge Flask Server on http://localhost:{port} ...")
    app.run(host="0.0.0.0", port=port, debug=True)
