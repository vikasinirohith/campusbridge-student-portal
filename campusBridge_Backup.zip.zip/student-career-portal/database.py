"""
CampusBridge Database Module
Handles SQLite connection, schema definition, seed data, and query helpers.
"""

import os
import json
import sqlite3
from datetime import datetime
from werkzeug.security import generate_password_hash

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "campusbridge.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    """Initializes tables and seeds initial realistic mock data if empty."""
    conn = get_db()
    cursor = conn.cursor()

    # 1. Students Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            phone TEXT DEFAULT '',
            university TEXT DEFAULT '',
            department TEXT DEFAULT 'Computer Science',
            degree TEXT DEFAULT 'B.Tech / B.S. Computer Science',
            grad_year INTEGER DEFAULT 2026,
            cgpa REAL DEFAULT 8.0,
            skills TEXT DEFAULT '[]',
            bio TEXT DEFAULT '',
            resume_filename TEXT DEFAULT '',
            resume_filesize TEXT DEFAULT '',
            resume_uploaded_at TEXT DEFAULT '',
            github_url TEXT DEFAULT '',
            linkedin_url TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # 2. Jobs Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            company TEXT NOT NULL,
            logo_bg TEXT DEFAULT '#4F46E5',
            company_initial TEXT DEFAULT 'C',
            type TEXT DEFAULT 'Internship',
            work_mode TEXT DEFAULT 'Hybrid',
            location TEXT DEFAULT 'Remote',
            department TEXT DEFAULT 'Software Engineering',
            stipend TEXT DEFAULT '$5,000 / month',
            stipend_numeric REAL DEFAULT 5000,
            duration TEXT DEFAULT '12 Weeks',
            min_cgpa REAL DEFAULT 7.5,
            eligible_batches TEXT DEFAULT '[]',
            required_skills TEXT DEFAULT '[]',
            preferred_skills TEXT DEFAULT '[]',
            deadline TEXT DEFAULT '',
            description TEXT DEFAULT '',
            openings INTEGER DEFAULT 3,
            posted_at TEXT DEFAULT '',
            featured INTEGER DEFAULT 0
        )
    """)

    # 3. Applications Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS applications (
            id TEXT PRIMARY KEY,
            student_id TEXT NOT NULL,
            job_id TEXT NOT NULL,
            job_title TEXT NOT NULL,
            company TEXT NOT NULL,
            status TEXT DEFAULT 'applied',
            applied_date TEXT NOT NULL,
            resume_used TEXT DEFAULT '',
            cover_note TEXT DEFAULT '',
            match_score INTEGER DEFAULT 0,
            timeline TEXT DEFAULT '[]',
            notes TEXT DEFAULT '',
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
        )
    """)

    # 4. Bookmarks Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS bookmarks (
            student_id TEXT NOT NULL,
            job_id TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (student_id, job_id)
        )
    """)

    conn.commit()

    # Check and Seed initial data
    cursor.execute("SELECT COUNT(*) FROM students")
    student_count = cursor.fetchone()[0]

    if student_count == 0:
        seed_data(conn)

    conn.close()

def seed_data(conn):
    cursor = conn.cursor()
    default_pw_hash = generate_password_hash("password123")

    # Seed Students
    students_data = [
        (
            "student-1",
            "Alex Rivera",
            "alex.rivera@university.edu",
            default_pw_hash,
            "+1 (555) 234-5678",
            "Tech State University",
            "Computer Science",
            "B.Tech / B.S. Computer Science",
            2026,
            8.6,
            json.dumps(["JavaScript", "React", "Node.js", "Python", "SQL", "Git", "REST APIs", "Tailwind CSS"]),
            "Passionate CS pre-final year student specializing in full-stack web applications and cloud architecture. Built 4 production-ready projects.",
            "Alex_Rivera_Resume_2026.pdf",
            "245 KB",
            "2026-10-15",
            "https://github.com/alexrivera-demo",
            "https://linkedin.com/in/alexrivera-demo"
        ),
        (
            "student-2",
            "Priya Sharma",
            "priya.sharma@institute.ac.in",
            default_pw_hash,
            "+91 98765 43210",
            "National Institute of Technology",
            "Data Science & AI",
            "B.Tech Data Science & AI",
            2025,
            9.2,
            json.dumps(["Python", "Machine Learning", "Pandas", "PyTorch", "SQL", "Tableau", "Git", "Statistics", "C++"]),
            "Final year AI/ML enthusiast with 2 research papers in NLP and automated feature engineering. Seeking Summer ML Internship.",
            "Priya_Sharma_Resume_Final.pdf",
            "310 KB",
            "2026-11-01",
            "https://github.com/priyasharma-ai",
            "https://linkedin.com/in/priyasharma-data"
        ),
        (
            "student-3",
            "Marcus Chen",
            "m.chen@statecollege.edu",
            default_pw_hash,
            "+1 (555) 876-5432",
            "Metro Arts & Science College",
            "Product & UI/UX",
            "B.S. Interactive Media & Software",
            2027,
            7.4,
            json.dumps(["Figma", "HTML", "CSS", "JavaScript", "UI/UX Design", "User Research", "Wireframing"]),
            "Sophomore UI designer & front-end enthusiast aiming to bridge user experience with clean, accessible component code.",
            "Marcus_Chen_Product_Design_CV.pdf",
            "420 KB",
            "2026-11-08",
            "https://github.com/marcuschen-design",
            "https://linkedin.com/in/marcuschen-ux"
        )
    ]

    cursor.executemany("""
        INSERT INTO students (
            id, name, email, password_hash, phone, university, department, degree,
            grad_year, cgpa, skills, bio, resume_filename, resume_filesize,
            resume_uploaded_at, github_url, linkedin_url
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, students_data)

    # Seed Jobs
    jobs_data = [
        (
            "job-101", "Software Engineering Intern - Frontend", "Stripe", "#635BFF", "S",
            "Internship", "Hybrid", "San Francisco, CA / Seattle, WA", "Software Engineering",
            "$5,200 / month", 5200, "12 Weeks (Summer 2027)", 8.0,
            json.dumps([2026, 2027]),
            json.dumps(["JavaScript", "React", "TypeScript", "CSS", "Git"]),
            json.dumps(["GraphQL", "Next.js", "Performance Optimization"]),
            "2026-12-15",
            "Join the Stripe Global Dashboard team. You will build user-facing financial tooling used by millions of merchants worldwide, ensuring sub-second response times and bulletproof accessibility.",
            8, "2026-11-02", 1
        ),
        (
            "job-102", "AI & Machine Learning Research Intern", "Google Research", "#4285F4", "G",
            "Internship", "On-Site", "Mountain View, CA / Bengaluru, India", "Data & AI",
            "$6,500 / month", 6500, "16 Weeks", 8.5,
            json.dumps([2025, 2026]),
            json.dumps(["Python", "Machine Learning", "PyTorch", "Mathematics", "Statistics"]),
            json.dumps(["Transformers", "CUDA", "TensorFlow"]),
            "2026-11-30",
            "Work directly with core DeepMind & Google Brain scientists on generative model evaluation, multimodal reasoning architectures, and efficient frontier model inference.",
            5, "2026-10-28", 1
        ),
        (
            "job-103", "Junior Full Stack Developer", "Atlassian", "#0052CC", "A",
            "Full-Time", "Remote", "Remote (Global)", "Software Engineering",
            "$92,000 / year", 7666, "Full-Time Graduate Role", 7.5,
            json.dumps([2025, 2026]),
            json.dumps(["JavaScript", "Node.js", "React", "SQL", "REST APIs"]),
            json.dumps(["Docker", "AWS", "Jira API"]),
            "2026-12-31",
            "Build collaborative features for Jira and Confluence cloud services. Open to graduating seniors with strong fundamentals in distributed backend systems and responsive modern web frontend.",
            12, "2026-11-05", 0
        ),
        (
            "job-104", "Product Design (UI/UX) Intern", "Figma", "#F24E1E", "F",
            "Internship", "Remote", "San Francisco, CA / Remote", "Product & UI/UX",
            "$4,800 / month", 4800, "10 Weeks", 7.0,
            json.dumps([2026, 2027, 2028]),
            json.dumps(["Figma", "UI/UX Design", "Wireframing", "User Research"]),
            json.dumps(["Design Systems", "Prototyping", "HTML/CSS basics"]),
            "2026-12-20",
            "Design the future of design. You'll partner with senior product designers and engineers to conceptualize creative collaborative workflows and build intuitive canvas interactions.",
            4, "2026-11-08", 1
        ),
        (
            "job-105", "Cloud & DevOps Engineering Intern", "Microsoft Azure", "#0089D6", "M",
            "Internship", "Hybrid", "Redmond, WA / Austin, TX", "Cloud & Infrastructure",
            "$5,800 / month", 5800, "12 Weeks", 8.0,
            json.dumps([2026, 2027]),
            json.dumps(["Python", "Linux", "Git", "Networking", "Docker"]),
            json.dumps(["Kubernetes", "Terraform", "Azure CLI", "Bash"]),
            "2026-12-10",
            "Support Azure infrastructure automation, CI/CD pipeline modernization, and telemetry monitoring for hyperscale container deployments.",
            6, "2026-10-30", 0
        ),
        (
            "job-106", "Quantitative Analytics & Tech Analyst", "Goldman Sachs", "#1C3C6B", "G",
            "Full-Time", "On-Site", "New York, NY / London, UK", "Finance & Quantitative",
            "$110,000 / year", 9166, "Full-Time Analyst Program", 8.8,
            json.dumps([2025]),
            json.dumps(["Python", "SQL", "Statistics", "C++", "Mathematics"]),
            json.dumps(["Financial Modeling", "Algorithms", "Time Series"]),
            "2026-11-25",
            "Develop algorithmic trading models, pricing frameworks, and real-time risk calculation engines for high-frequency financial markets. Extreme attention to mathematical rigor required.",
            3, "2026-10-18", 1
        ),
        (
            "job-107", "Cybersecurity Analyst Intern", "CrowdStrike", "#E01E26", "C",
            "Internship", "Remote", "Remote (US & Canada)", "Security & IT",
            "$4,500 / month", 4500, "12 Weeks", 7.8,
            json.dumps([2026, 2027]),
            json.dumps(["Networking", "Python", "Linux", "Security Principles"]),
            json.dumps(["Wireshark", "Reverse Engineering", "SOC Monitoring"]),
            "2026-12-05",
            "Join our Threat Intelligence Unit. Analyze adversary behavioral telemetry, identify zero-day vulnerability signatures, and craft automated detection heuristics.",
            4, "2026-11-04", 0
        ),
        (
            "job-108", "Autonomous Vehicle Systems Intern", "Tesla", "#CC0000", "T",
            "Internship", "On-Site", "Palo Alto, CA", "Core Engineering & Embedded",
            "$5,400 / month", 5400, "16 Weeks", 8.2,
            json.dumps([2026, 2027]),
            json.dumps(["C++", "Python", "Linux", "Git", "Robotics Basics"]),
            json.dumps(["ROS", "Computer Vision", "CAN Bus", "Embedded RTOS"]),
            "2026-12-18",
            "Develop low-latency sensor fusion and autopilot validation testbenches. Write rock-solid deterministic code that interfaces directly with real-time vehicle microcontrollers.",
            6, "2026-11-07", 1
        ),
        (
            "job-109", "Data Analyst & BI Intern", "Spotify", "#1DB954", "S",
            "Internship", "Hybrid", "New York, NY / Stockholm", "Data & AI",
            "$4,600 / month", 4600, "10 Weeks", 7.2,
            json.dumps([2026, 2027, 2028]),
            json.dumps(["SQL", "Tableau", "Python", "Data Storytelling"]),
            json.dumps(["BigQuery", "A/B Testing", "Excel Modeling"]),
            "2026-12-28",
            "Uncover how 600M+ music fans discover new creators. Build actionable executive dashboards, analyze playlist curation algorithms, and run multivariate feature experiments.",
            7, "2026-11-06", 0
        ),
        (
            "job-110", "Mobile App Developer (React Native / iOS)", "DoorDash", "#FF3008", "D",
            "Internship", "Hybrid", "San Francisco, CA", "Software Engineering",
            "$5,000 / month", 5000, "12 Weeks", 7.6,
            json.dumps([2026, 2027]),
            json.dumps(["JavaScript", "React", "Mobile Development", "REST APIs", "Git"]),
            json.dumps(["React Native", "TypeScript", "Swift", "State Management"]),
            "2026-12-22",
            "Build features used by millions of diners and couriers in real time. Work on instant dispatch interfaces, live GPS mapping overlays, and fluid checkout animations.",
            5, "2026-11-03", 0
        ),
        (
            "job-111", "Associate Product Manager (APM)", "Uber", "#000000", "U",
            "Full-Time", "On-Site", "San Francisco, CA / Seattle, WA", "Product & UI/UX",
            "$105,000 / year", 8750, "Full-Time Rotational APM", 8.0,
            json.dumps([2025, 2026]),
            json.dumps(["Product Strategy", "User Research", "Data Analytics", "Wireframing"]),
            json.dumps(["SQL", "Market Analysis", "Growth Experiments"]),
            "2026-12-12",
            "Accelerate your career through two 9-month rotations across Rider, Driver, and Uber Freight teams. Lead cross-functional engineering teams to launch high-impact product roadmaps.",
            4, "2026-10-25", 1
        ),
        (
            "job-112", "Backend Engineering Intern - Go / Distributed Systems", "Datadog", "#632CA6", "D",
            "Internship", "Remote", "Remote (US & Europe)", "Software Engineering",
            "$5,500 / month", 5500, "12 Weeks", 8.3,
            json.dumps([2026, 2027]),
            json.dumps(["Go", "Python", "SQL", "Linux", "Git"]),
            json.dumps(["Distributed Systems", "Kafka", "PostgreSQL", "Docker"]),
            "2026-12-08",
            "Help scale our cloud observability platform ingesting trillions of events per day. Optimize high-throughput streaming pipelines and microservices written in Go and Rust.",
            5, "2026-11-01", 0
        )
    ]

    cursor.executemany("""
        INSERT INTO jobs (
            id, title, company, logo_bg, company_initial, type, work_mode, location,
            department, stipend, stipend_numeric, duration, min_cgpa, eligible_batches,
            required_skills, preferred_skills, deadline, description, openings, posted_at, featured
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, jobs_data)

    # Seed Applications for student-1
    apps_data = [
        (
            "app-201", "student-1", "job-101",
            "Software Engineering Intern - Frontend", "Stripe",
            "interview", "2026-11-03", "Alex_Rivera_Resume_2026.pdf",
            "Excited about Stripe's financial infrastructure and user-facing design systems.",
            92,
            json.dumps([
                {"date": "2026-11-03", "title": "Application Submitted", "detail": "Applied via CampusBridge with 92% match score."},
                {"date": "2026-11-06", "title": "Resume Screened", "detail": "Profile approved by Campus Recruiting team."},
                {"date": "2026-11-10", "title": "Technical Round Scheduled", "detail": "Live coding interview scheduled for Nov 18, 2026."}
            ]),
            "Review React fiber architecture and Stripe UI Elements documentation before interview."
        ),
        (
            "app-202", "student-1", "job-103",
            "Junior Full Stack Developer", "Atlassian",
            "reviewing", "2026-11-07", "Alex_Rivera_Resume_2026.pdf",
            "Experienced with React and Node.js REST APIs with multiple deployed full-stack apps.",
            88,
            json.dumps([
                {"date": "2026-11-07", "title": "Application Submitted", "detail": "Applied with CGPA 8.6 (Exceeds min 7.5)."},
                {"date": "2026-11-09", "title": "Under Engineering Review", "detail": "Forwarded to hiring manager for Jira Core."}
            ]),
            "Follow up if no update by Nov 20."
        ),
        (
            "app-203", "student-1", "job-110",
            "Mobile App Developer (React Native / iOS)", "DoorDash",
            "applied", "2026-11-11", "Alex_Rivera_Resume_2026.pdf",
            "Passionate about fluid mobile experiences and real-time state synchronization.",
            78,
            json.dumps([
                {"date": "2026-11-11", "title": "Application Submitted", "detail": "Awaiting recruiter review."}
            ]),
            ""
        )
    ]

    cursor.executemany("""
        INSERT INTO applications (
            id, student_id, job_id, job_title, company, status, applied_date,
            resume_used, cover_note, match_score, timeline, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, apps_data)

    # Seed Bookmarks
    cursor.execute("INSERT OR IGNORE INTO bookmarks (student_id, job_id) VALUES (?, ?)", ("student-1", "job-102"))
    cursor.execute("INSERT OR IGNORE INTO bookmarks (student_id, job_id) VALUES (?, ?)", ("student-1", "job-104"))

    conn.commit()

# --- Helper Converters ---

def student_to_dict(row):
    if not row:
        return None
    d = dict(row)
    if "skills" in d and isinstance(d["skills"], str):
        try:
            d["skills"] = json.loads(d["skills"])
        except Exception:
            d["skills"] = []
    # Don't expose password_hash in general responses
    d.pop("password_hash", None)
    # Map snake_case to camelCase for frontend compatibility
    d["gradYear"] = d.get("grad_year")
    d["maxCgpa"] = 10.0
    d["resumeFileName"] = d.get("resume_filename", "")
    d["resumeFileSize"] = d.get("resume_filesize", "")
    d["resumeUploadedAt"] = d.get("resume_uploaded_at", "")
    d["githubUrl"] = d.get("github_url", "")
    d["linkedinUrl"] = d.get("linkedin_url", "")
    return d

def job_to_dict(row):
    if not row:
        return None
    d = dict(row)
    for key in ["eligible_batches", "required_skills", "preferred_skills"]:
        if key in d and isinstance(d[key], str):
            try:
                d[key] = json.loads(d[key])
            except Exception:
                d[key] = []
    # Map to camelCase for existing frontend
    d["logoBg"] = d.get("logo_bg")
    d["companyInitial"] = d.get("company_initial")
    d["workMode"] = d.get("work_mode")
    d["stipendNumeric"] = d.get("stipend_numeric")
    d["minCgpa"] = d.get("min_cgpa")
    d["eligibleBatches"] = d.get("eligible_batches")
    d["requiredSkills"] = d.get("required_skills")
    d["preferredSkills"] = d.get("preferred_skills")
    d["postedAt"] = d.get("posted_at")
    d["featured"] = bool(d.get("featured"))
    return d

def application_to_dict(row):
    if not row:
        return None
    d = dict(row)
    if "timeline" in d and isinstance(d["timeline"], str):
        try:
            d["timeline"] = json.loads(d["timeline"])
        except Exception:
            d["timeline"] = []
    d["studentId"] = d.get("student_id")
    d["jobId"] = d.get("job_id")
    d["jobTitle"] = d.get("job_title")
    d["appliedDate"] = d.get("applied_date")
    d["resumeUsed"] = d.get("resume_used")
    d["coverNote"] = d.get("cover_note")
    d["matchScore"] = d.get("match_score")
    return d
